package mvc_controller;


import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mvc_service.GuestServiceImpl;

@WebServlet("*.guest")
public class GuestController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public GuestController() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest req, HttpServletResponse res) 
			throws ServletException, IOException {
		actionDo(req,res);
	}
	protected void doPost(HttpServletRequest req, HttpServletResponse res) 
			throws ServletException, IOException {
		actionDo(req,res);
	}
	protected void actionDo(HttpServletRequest req,HttpServletResponse res) 
			throws ServletException, IOException{
		req.setCharacterEncoding("UTF-8");
		String viewPage="";
		String uri=req.getRequestURI();
		String contextPath=req.getContextPath();
		String url=uri.substring(contextPath.length());	//uri.substring(beginIndex);
		GuestServiceImpl service=new GuestServiceImpl();
		//첫 페이지
		if(url.equals("/enterpage.guest") || url.equals("/*.guest")) {
			service.showbook(req,res);
			viewPage="/jsp/common/enterpage.jsp";
		}
		//로그인 절차
		else if(url.equals("/login.guest") || url.equals("/*.login.guest")) {
			req.setAttribute("cnt", 2);
			viewPage="/jsp/guest/login.jsp";
		}
		else if(url.equals("/loginPro.guest")) {
			viewPage=service.loginPro(req, res);
		}
		//회원가입
		else if(url.equals("/signup.guest")) {
			viewPage="/jsp/guest/signup.jsp";
		}
		else if(url.equals("/signupPro.guest")) {
			viewPage=service.inputPro(req, res);
		}
		//아이디 중복체크
		else if(url.equals("/confirmId.guest")) {
			viewPage=service.confirmId(req, res);
		}
		//로그아웃
		else if(url.equals("/logout.guest")) {
			req.getSession().setAttribute("memId", null);
			req.setAttribute("cnt", 2);
			viewPage="/jsp/guest/login.jsp";
		}
		//정보수정
		else if(url.equals("/user_change.guest")) {
			viewPage=service.modifyView(req, res);
		}
		else if(url.equals("/changePro.guest")) {
			viewPage=service.modifyPro(req, res);
		}
		//회원탈퇴
		else if(url.equals("/user_out.guest")) {
			viewPage="/jsp/guest/user_out.jsp";
		}
		else if(url.equals("/user_outPro.guest")) {
			viewPage=service.deletePro(req, res);
		}
		//회원정보
		else if(url.equals("/user_info.guest")) {
			viewPage=service.infoPro(req, res);
		}
		else if(url.equals("/findid.guest")) {
			viewPage="/jsp/guest/findid.jsp";
		}
		else if(url.equals("/findpwd.guest")) {
			viewPage="/jsp/guest/findpwd.jsp";
		}
		else if(url.equals("/findidPro.guest")) {
			viewPage=service.findid(req,res);
		}
		else if(url.equals("/findpwdPro.guest")) {
			viewPage=service.findpwd(req,res);
		}
		//메인화면	
		else if(url.equals("/loginok_Main.guest")) {
			viewPage=service.showbook(req,res);
		}
		
		else if(url.equals("/bookimg_info.guest")) {
			service.searchimg(req,res);
			viewPage="/jsp/guest/bookimg_info.jsp";
		}
		//장바구니 추가
		else if(url.equals("/cartadd.guest")) {
			viewPage=service.cartadd(req, res);
		}
		//장바구니 삭제
		else if(url.equals("/cartdelete.guest")) {
			viewPage=service.cartdelete(req, res);
		}
		//장바구니 목록
		else if(url.equals("/cart.guest")) {
			viewPage=service.cartlist(req, res);
		}
		//주문목록 추가
		else if(url.equals("/orderadd.guest")) {
			viewPage=service.orderadd(req, res);
		}
		//주문 목록
		else if(url.equals("/order.guest")) {
			service.orderlist(req, res);
			viewPage="/jsp/guest/order.jsp";
		}
		//도서 정보
		else if(url.equals("/book_info.guest")) {
			viewPage=service.search(req, res);
		}
		//도서 주제별 페이지 이동
		else if(url.equals("/book_best.guest")) {
			service.showbook(req, res);
			viewPage="/jsp/guest/book_best.jsp";
		}else if(url.equals("/book_in.guest")) {
			service.showbook(req, res);
			viewPage="/jsp/guest/book_in.jsp";
		}else if(url.equals("/book_out.guest")) {
			service.showbook(req, res);
			viewPage="/jsp/guest/book_out.jsp";
		}else if(url.equals("/book_new.guest")) {
			service.showbook(req, res);
			viewPage="/jsp/guest/book_new.jsp";
		}
		//환불요청가능 목록 불러오기
		else if(url.equals("/refund.guest")) {
			service.confirmOklist(req, res);	//결제승인이라고 보이는 창만 가져옴
			viewPage="/jsp/guest/refund.jsp";
		}
		//환불요청
		else if(url.equals("/refundPro.guest")) {
			service.refund(req, res);	//환불요청이라고 찍어주는 서비스
			viewPage="/jsp/guest/refundPro.jsp";
		}
		//임시페이지
		else if(url.equals("/cartPro.guest")) {
			viewPage="/jsp/guest/cartPro.jsp";
		}
		else if(url.equals("/orderPro.guest")) {
			viewPage="/jsp/guest/orderPro.jsp";
		}
		//지도 페이지
		else if(url.equals("/map.guest")) {
			viewPage="/jsp/guest/map.jsp";
		}
		//게시판 목록
		else if(url.equals("/board.guest")) {
			service.boardList(req, res);
			viewPage="/jsp/guest/board.jsp";
		}
		//게시글 작성
		else if(url.equals("/board_write.guest")) {
			viewPage=service.boardwrite(req,res);
			viewPage="/jsp/guest/board_write.jsp";
		}
		//상세 게시글 읽기
		else if(url.equals("/board_read.guest")) {
			service.boardread(req, res);
			service.commentlist(req,res);
			viewPage="/jsp/guest/board_read.jsp";
		}
		//게시글 수정(비밀번호)
		else if(url.equals("/board_modify.guest")) {
			int boardnum=Integer.parseInt(req.getParameter("boardnum"));
			int pageNum=Integer.parseInt(req.getParameter("pageNum"));
			req.setAttribute("boardnum", boardnum);
			req.setAttribute("pageNum", pageNum);
			viewPage="/jsp/guest/board_modify.jsp";
		}
		//게시글 수정 상세
		else if(url.equals("/bm_view.guest")) {
			viewPage=service.boardmodify(req, res);
		}
		//게시글 목록 이동.
		else if(url.equals("/bm_Pro.guest")) {
			viewPage=service.bmPro(req, res);
		}
		//게시글 삽입
		else if(url.equals("/boardinsert.guest")) {
			viewPage=service.boardinsert(req, res);
		}
		//게시글 삭제
		else if(url.equals("/board_delete.guest")) {
			int boardnum=Integer.parseInt(req.getParameter("boardnum"));
			int pageNum=Integer.parseInt(req.getParameter("pageNum"));
			req.setAttribute("boardnum", boardnum);
			req.setAttribute("pageNum", pageNum);
			viewPage="/jsp/guest/board_delete.jsp";
		}
		//게시글 목록 이동
		else if(url.equals("/bd_Pro.guest")) {
			viewPage=service.boarddelete(req, res);
		}
		
		//상품 목록
		else if(url.equals("/deal.guest")) {
			service.deallist(req, res);
			viewPage="/jsp/guest/deal.jsp";
		}
		//상품 등록
		else if(url.equals("/deal_register.guest")) {
			service.dealregister(req,res);
			viewPage="/jsp/guest/deal_register.jsp";
		}
		//상품 상세페이지
		else if(url.equals("/deal_read.guest")) {
			service.dealread(req,res);
			viewPage="/jsp/guest/deal_read.jsp";
		}
		//상품 요청
		else if(url.equals("/request.guest")) {
			service.dealrequest(req,res);
			viewPage="/jsp/guest/request.jsp";
		}
		//상품 추가 후 화면이동
		else if(url.equals("/drPro.guest")) {
			service.dealinsert(req,res);
			viewPage="/jsp/guest/dealPro.jsp";
		}
		//요청 db 추가 후 화면이동
		else if(url.equals("/dqPro.guest")) {
			service.dqinsert(req,res);
			viewPage="/jsp/guest/dealPro.jsp";
		}
		//쪽지함 이동
		else if(url.equals("/note.guest")) {
			service.notelist(req,res);
			viewPage="/jsp/guest/note.jsp";
		}
		//쪽지함 읽기
		else if(url.equals("/note_read.guest")) {
			service.noteread(req,res);
			viewPage="/jsp/guest/note_read.jsp";
		}
		//거래요청 수락
		else if(url.equals("/requestok.guest")) {
			service.requestok(req,res);
			viewPage="/jsp/guest/requestok.jsp";
		}
		//거래요청 수락
		else if(url.equals("/requestno.guest")) {
			service.requestno(req,res);
			viewPage="/jsp/guest/requestno.jsp";
		}
		else if(url.equals("/commentadd.guest")) {
			viewPage="/jsp/guest/commentadd.jsp";
		}
		else if(url.equals("/commentPro.guest")) {
			service.addcomment(req,res);
			viewPage="/jsp/guest/commentPro.jsp";
		}
		RequestDispatcher dispatcher=req.getRequestDispatcher(viewPage);
		dispatcher.forward(req, res);	
	}
}
