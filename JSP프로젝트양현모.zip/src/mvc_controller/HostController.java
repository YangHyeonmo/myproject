package mvc_controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc_service.GuestServiceImpl;
import mvc_service.HostServiceImpl;

@WebServlet("*.host")
public class HostController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public HostController() {
        super();
        // TODO Auto-generated constructor stub
    }
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
    		throws ServletException, IOException {
		actionDo(req,res);
	}
    protected void doPost(HttpServletRequest req, HttpServletResponse res) 
    		throws ServletException, IOException {
		actionDo(req,res);
	}
    protected void actionDo(HttpServletRequest req,HttpServletResponse res) 
			throws ServletException, IOException{
		req.setCharacterEncoding("UTF-8");
		String viewPage="";
		String uri=req.getRequestURI();
		String contextPath=req.getContextPath();
		String url=uri.substring(contextPath.length());	//uri.substring(beginIndex);
		HostServiceImpl service=new HostServiceImpl();
		
		//메인페이지
		if(url.equals("/admin_main.host")) {
			viewPage="/jsp/host/admin_main.jsp";
		}
		//도서목록
		else if(url.equals("/booklist.host")) {
			service.bookList(req, res);
			viewPage="/jsp/host/booklist.jsp";
		}
		//도서추가화면
		else if(url.equals("/book_add.host")) {
			viewPage="/jsp/host/book_add.jsp";
		}
		//도서추가
		else if(url.equals("/bookinsert.host")) {
			service.bookadd(req, res);
			viewPage="/jsp/host/bookPro.jsp";
		}
		//도서 수정 화면
		else if(url.equals("/book_update.host")) {
			viewPage="/jsp/host/book_update.jsp";
		}
		//도서수정
		else if(url.equals("/bookupdate.host")) {
			service.bookupdate(req, res);
			viewPage="/jsp/host/bookPro.jsp";
		}
		//도서 삭제화면
		else if(url.equals("/book_delete.host")) {
			service.bookdelete(req,res);
			viewPage="/jsp/host/bookPro.jsp";
		}
		//회원목록
		else if(url.equals("/memberlist.host")) {
			service.memberList(req, res);
			viewPage="/jsp/host/memberlist.jsp";
		}
		//회원 삭제화면
		else if(url.equals("/member_delete.host")) {
			service.memberdelete(req,res);
			viewPage="/jsp/host/memberPro.jsp";
		}
		//주문목록
		else if(url.equals("/orderlist.host")) {
			service.orderList(req, res);
			viewPage="/jsp/host/orderlist.jsp";
		}
		//결제요청 리스트만 추출
		else if(url.equals("/orderconfirm.host")) {
			service.confirmlist(req,res); //결제요청이라고 주문상태에 있는 리스트만 뽑아주는서비스
			viewPage="/jsp/host/orderconfirm.jsp";
		}
		//환불요청리스트만 추출
		else if(url.equals("/ordercancel.host")) {
			service.cancellist(req,res);
			viewPage="/jsp/host/ordercancel.jsp";
		}
		//결제승인해주는 화면
		else if(url.equals("/confirmPro.host")) {
			service.confirm(req,res);	//결제승인 찍어주는 서비스
			viewPage="/jsp/host/orderPro.jsp";
		}
		//결제취소해주는 화면
		else if(url.equals("/cancelPro.host")) {
			service.cancel(req,res);	//결제취소찍어주는 서비스
			viewPage="/jsp/host/orderPro.jsp";
		}
		//결산 페이지
		else if(url.equals("/orderresult.host")) {
			service.resultlist(req,res);
			viewPage="/jsp/host/orderresult.jsp";
		}
		//도서종류별 결산페이지
		else if(url.equals("/resultbk.host")) {
			service.Chart(req,res);
			viewPage="/jsp/host/resultbk.jsp";
		}
		//도서가격별 결산페이지
		else if(url.equals("/resultprice.host")) {
			service.priceChart(req,res);
			viewPage="/jsp/host/resultprice.jsp";
		}
		else if(url.equals("/boardadmin.host")) {
			GuestServiceImpl gservice=new GuestServiceImpl();
			gservice.boardList(req, res);
			viewPage="/jsp/host/boardadmin.jsp";
		}
		else if(url.equals("/boarddelete.host")) {
			service.boarddelete(req,res);
			viewPage="/jsp/host/boardPro.jsp";
		}
		else if(url.equals("/dealadmin.host")) {
			GuestServiceImpl gservice=new GuestServiceImpl();
			gservice.deallist(req, res);
			viewPage="/jsp/host/dealadmin.jsp";
		}
		else if(url.equals("/dealdelete.host")) {
			service.dealdelete(req,res);
			viewPage="/jsp/host/dealPro.jsp";
		}
		else if(url.equals("/commentdelete.host")) {
			service.commentdelete(req,res);
			viewPage="/jsp/host/commentPro.jsp";
		}
		RequestDispatcher dispatcher=req.getRequestDispatcher(viewPage);
		dispatcher.forward(req, res);
		
    }
}
