package mvc_vo;

import java.sql.Timestamp;

public class GuestVO {
	//===================회원정보================
	private String id;
	private String password;
	private String name;
	private String hp;
	private String email;
	private int postnum;
	private String address;
	private String jumin;	
	//===================게시판===================
	private int boardnum;
	private String subject;
	private String content;
	private int readCnt;
	private Timestamp reg_date;
	private int commentnum;
	private String commentid;
	private int com_level;
	
	//==================중고거래====================
	private int dealnum;
	private String dealimg;
	private String dealname;
	private String dealhow;
	private String dealplace;
	private String buyer;
	private String seller;
	private String dealstate;
	public int getCom_level() {
		return com_level;
	}
	public void setCom_level(int com_level) {
		this.com_level = com_level;
	}
	public String getCommentid() {
		return commentid;
	}
	public void setCommentid(String commentid) {
		this.commentid = commentid;
	}
	public int getCommentnum() {
		return commentnum;
	}
	public void setCommentnum(int commentnum) {
		this.commentnum = commentnum;
	}
	public String getDealstate() {
		return dealstate;
	}
	public void setDealstate(String dealstate) {
		this.dealstate = dealstate;
	}
	public String getSeller() {
		return seller;
	}
	public void setSeller(String seller) {
		this.seller = seller;
	}
	public String getBuyer() {
		return buyer;
	}
	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}
	private String category;
	private int dealprice;
	private int requestnum;
	private int requestprice;
	private String message;
	private String requeststate;
	public int getRequestnum() {
		return requestnum;
	}
	public void setRequestnum(int requestnum) {
		this.requestnum = requestnum;
	}
	public int getRequestprice() {
		return requestprice;
	}
	public void setRequestprice(int requestprice) {
		this.requestprice = requestprice;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getRequeststate() {
		return requeststate;
	}
	public void setRequeststate(String requeststate) {
		this.requeststate = requeststate;
	}
	public int getDealnum() {
		return dealnum;
	}
	public void setDealnum(int dealnum) {
		this.dealnum = dealnum;
	}
	
	public String getDealimg() {
		return dealimg;
	}
	public void setDealimg(String dealimg) {
		this.dealimg = dealimg;
	}
	public String getDealname() {
		return dealname;
	}
	public void setDealname(String dealname) {
		this.dealname = dealname;
	}
	public String getDealhow() {
		return dealhow;
	}
	public void setDealhow(String dealhow) {
		this.dealhow = dealhow;
	}
	public String getDealplace() {
		return dealplace;
	}
	public void setDealplace(String dealplace) {
		this.dealplace = dealplace;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getDealprice() {
		return dealprice;
	}
	public void setDealprice(int dealprice) {
		this.dealprice = dealprice;
	}
	public String getJumin() {
		return jumin;
	}
	public void setJumin(String jumin) {
		this.jumin = jumin;
	}
	private String pwd;	//게시판에서의 비밀번호
	public String getPwd() {
		return pwd;
	}
	public int getBoardnum() {
		return boardnum;
	}
	public void setBoardnum(int boardnum) {
		this.boardnum = boardnum;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getReadCnt() {
		return readCnt;
	}
	public void setReadCnt(int readCnt) {
		this.readCnt = readCnt;
	}
	
	public Timestamp getReg_date() {
		return reg_date;
	}
	public void setReg_date(Timestamp reg_date) {
		this.reg_date = reg_date;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getHp() {
		return hp;
	}
	public void setHp(String hp) {
		this.hp = hp;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getPostnum() {
		return postnum;
	}
	public void setPostnum(int postnum) {
		this.postnum = postnum;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
