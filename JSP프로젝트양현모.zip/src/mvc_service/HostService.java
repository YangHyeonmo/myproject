package mvc_service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface HostService {
			public void bookadd(HttpServletRequest req,HttpServletResponse res);
			public void bookupdate(HttpServletRequest req, HttpServletResponse res);
			public void bookdelete(HttpServletRequest req, HttpServletResponse res);
			public void memberdelete(HttpServletRequest req, HttpServletResponse res);
			public void bookList(HttpServletRequest req,HttpServletResponse res);
			public void memberList(HttpServletRequest req,HttpServletResponse res);
			//고객용
			public void orderList(HttpServletRequest req,HttpServletResponse res);
			//관리자용
			public void confirmlist(HttpServletRequest req, HttpServletResponse res);
			public void confirm(HttpServletRequest req, HttpServletResponse res);
			public void cancel(HttpServletRequest req, HttpServletResponse res);
			public void cancellist(HttpServletRequest req, HttpServletResponse res);
			public void resultlist(HttpServletRequest req, HttpServletResponse res);
			public void Chart(HttpServletRequest req, HttpServletResponse res);
			public void priceChart(HttpServletRequest req, HttpServletResponse res);
			public void commentdelete(HttpServletRequest req, HttpServletResponse res);
			
}
