package mvc_service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface GuestService {

		//중복확인
		public String confirmId(HttpServletRequest req,HttpServletResponse res);
		//회원가입처리
		public String inputPro(HttpServletRequest req,HttpServletResponse res);
		//로그인처리
		public String loginPro(HttpServletRequest req,HttpServletResponse res);
		//회원수정처리
		public String modifyView(HttpServletRequest req, HttpServletResponse res);
		public String modifyPro(HttpServletRequest req, HttpServletResponse res);
		//회원탈퇴처리
		public String deletePro(HttpServletRequest req, HttpServletResponse res);
		//회원정보처리
		public String infoPro(HttpServletRequest req,HttpServletResponse res);
		//게시판 목록처리
		public void boardList(HttpServletRequest req,HttpServletResponse res);
		//게시판 작성
		public String boardwrite(HttpServletRequest req, HttpServletResponse res);
		//게시판 삽입
		public String boardinsert(HttpServletRequest req, HttpServletResponse res);
		//게시판 상세처리
		public void boardread(HttpServletRequest req,HttpServletResponse res);
		//게시글 수정 비밀번호 일치 여부 처리
		public String boardmodify(HttpServletRequest req, HttpServletResponse res);
		//게시글 수정  처리
		public String bmPro(HttpServletRequest req, HttpServletResponse res);
		//게시글 삭제 비밀번호 일치 여부 처리
		public String boarddelete(HttpServletRequest req, HttpServletResponse res);
		//검색 처리
		public String search(HttpServletRequest req,HttpServletResponse res);
		//장바구니 추가
		public String cartadd(HttpServletRequest req,HttpServletResponse res);
		public String cartdelete(HttpServletRequest req,HttpServletResponse res);
		//장바구니 목록
		public String cartlist(HttpServletRequest req,HttpServletResponse res);
		//장바구니 목록
		public void orderlist(HttpServletRequest req,HttpServletResponse res);
		//장바구니 추가
		public String orderadd(HttpServletRequest req, HttpServletResponse res);
		//결산ok 리스트
		public void confirmOklist(HttpServletRequest req, HttpServletResponse res);
		//거래 목록
		public void deallist(HttpServletRequest req, HttpServletResponse res);
		//거래 상세
		public void dealread(HttpServletRequest req, HttpServletResponse res);
		//거래물품 등록
		public void dealregister(HttpServletRequest req, HttpServletResponse res);	
		//거래 요청
		public void dealrequest(HttpServletRequest req, HttpServletResponse res) ;
		//거래요청db 추가
		public void dqinsert(HttpServletRequest req, HttpServletResponse res);
		//쪽지함리스트
		public void notelist(HttpServletRequest req, HttpServletResponse res);
		public void noteread(HttpServletRequest req, HttpServletResponse res);
		//요청수락
		public void requestok(HttpServletRequest req, HttpServletResponse res);
		public void requestno(HttpServletRequest req, HttpServletResponse res);
		public void addcomment(HttpServletRequest req, HttpServletResponse res); 
		//환불
		public void refund(HttpServletRequest req, HttpServletResponse res);
		public void commentlist(HttpServletRequest req, HttpServletResponse res);
		public String findid(HttpServletRequest req, HttpServletResponse res);
		public String findpwd(HttpServletRequest req, HttpServletResponse res);
		public String showbook(HttpServletRequest req, HttpServletResponse res);
}
