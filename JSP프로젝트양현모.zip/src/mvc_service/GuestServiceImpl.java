package mvc_service;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import mvc_persistence.GuestDAO;
import mvc_persistence.GuestDAOImpl;
import mvc_persistence.HostDAO;
import mvc_persistence.HostDAOImpl;
import mvc_vo.GuestVO;
import mvc_vo.HostVO;


public class GuestServiceImpl implements GuestService {

	@Override
	public String confirmId(HttpServletRequest req, HttpServletResponse res) {
		String id=(String)req.getParameter("id");
		GuestDAO dao=GuestDAOImpl.getInstance();
		int cnt=dao.idCheck(id);
		req.setAttribute("cnt", cnt);
		req.setAttribute("id", id);
		return "/jsp/guest/confirmId.jsp";
	}
	@Override
	public String inputPro(HttpServletRequest req, HttpServletResponse res) {
		GuestVO vo=new GuestVO();
		vo.setId(req.getParameter("txtUserName"));
		vo.setPassword(req.getParameter("txtPassword"));
		String hp="";
		String hp1=req.getParameter("hp1");
		String hp2=req.getParameter("hp2");
		String hp3=req.getParameter("hp3");
		hp=hp1+"-"+hp2+"-"+hp3;
		vo.setHp(hp);
		String email=req.getParameter("txtEmail");
		vo.setEmail(email);
		int postnum=Integer.parseInt(req.getParameter("postnum"));
		vo.setPostnum(postnum);
		String address="";
		String addr1=req.getParameter("addr1");
		String addr2=req.getParameter("addr2");
		address=addr1+" "+addr2;
		vo.setAddress(address);
		String name=req.getParameter("username");
		vo.setName(name);
		String jumin="";
		String jumin1=req.getParameter("jumin1");
		String jumin2=req.getParameter("jumin2");
		jumin=jumin1+"-"+jumin2;
		vo.setJumin(jumin);		
		GuestDAO dao=GuestDAOImpl.getInstance();	
		int cnt=dao.insertGuest(vo);
		req.setAttribute("cnt", cnt);
		return "/jsp/guest/login.jsp";		
	}
	@Override
	public String loginPro(HttpServletRequest req, HttpServletResponse res) {
		String id=req.getParameter("txtUserName");
		String pwd=req.getParameter("txtPassword");
		GuestDAO dao=GuestDAOImpl.getInstance();
		int logincnt=dao.idPwdCheck(id, pwd);
		if(logincnt==1) {
			req.getSession().setAttribute("memId", id);
		}
		req.setAttribute("cnt", logincnt);
		return "/jsp/guest/login.jsp";
	}
	public String modifyView(HttpServletRequest req, HttpServletResponse res) {
		int modifycnt=1;
		String id=(String)req.getSession().getAttribute("memId");
		GuestDAO dao=GuestDAOImpl.getInstance();
		GuestVO vo=dao.getMemberinfo(id);
		req.setAttribute("vo", vo);
		req.setAttribute("cnt", modifycnt);
		return "/jsp/guest/user_change.jsp";
	}
	@Override
	public String modifyPro(HttpServletRequest req, HttpServletResponse res) {
		int updatecnt=0;
		GuestVO vo=new GuestVO();
		vo.setId((String) req.getSession().getAttribute("memId"));
		vo.setPassword(req.getParameter("txtPassword"));
		String hp="";
		String hp1=req.getParameter("hp1");
		String hp2=req.getParameter("hp2");
		String hp3=req.getParameter("hp3");
		hp=hp1+"-"+hp2+"-"+hp3;
		vo.setHp(hp);
		String email=req.getParameter("txtEmail");
		vo.setEmail(email);
		int postnum=Integer.parseInt(req.getParameter("postnum"));
		vo.setPostnum(postnum);
		String address=req.getParameter("addr1")+req.getParameter("addr2");
		vo.setAddress(address);
		String name=req.getParameter("username");
		vo.setName(name);
		GuestDAO dao=GuestDAOImpl.getInstance();
		updatecnt=dao.updateMember(vo);
		req.setAttribute("cnt", updatecnt);
		return "/jsp/guest/changePro.jsp";
	}
	@Override
	public String deletePro(HttpServletRequest req, HttpServletResponse res) {
		int deletecnt=0;
		String id=(String)req.getSession().getAttribute("memId");
		String pwd=(String)req.getParameter("pwd");
		GuestDAO dao=GuestDAOImpl.getInstance();
		deletecnt=dao.deleteMember(id, pwd);
		req.setAttribute("cnt", deletecnt);
		return "/jsp/guest/user_outPro.jsp";
	}
	@Override
	public String infoPro(HttpServletRequest req, HttpServletResponse res) {
		GuestVO vo=new GuestVO();
		String id=(String)req.getSession().getAttribute("memId");
		GuestDAO dao=GuestDAOImpl.getInstance();
		vo=dao.getMemberinfo(id);
		req.setAttribute("vo", vo);
		return "/jsp/guest/user_info.jsp";
	}
	@Override
	public void boardList(HttpServletRequest req, HttpServletResponse res) {
		int pageSize=10; //한 페이지당 출력할 글 갯수
		int pageBlock=3; //한 블럭당 페이지 갯수
		int cnt=0; //글 갯수
		int start=0; //현재 페이지 시작 글번호
		int end=0; //현재 페이지 마지막 글번호
		int number=0; //출력용 글번호
		String pageNum=null; //페이지 번호
		int currentPage=0; //현재페이지
		int pageCount=0; //페이지 갯수
		int startPage=0; //시작페이지
		int endPage=0; //마지막페이지
		GuestDAO dao=GuestDAOImpl.getInstance();
		pageNum=req.getParameter("pageNum");
		String board=null;
		String boardselect=null;
		String admin="Admin";
		if(pageNum==null) {
			pageNum="1";
		}
		currentPage=Integer.parseInt(pageNum);
		start=(currentPage-1)* pageSize+1;	
		end=start+pageSize-1;
		if(req.getParameter("findboard")==null) {
			cnt=dao.getBoardCnt();			
		}else {
			cnt=dao.getPageCnt(req.getParameter("findboard"), req.getParameter("boardselect"),admin);
		}
		pageCount=(cnt/ pageSize) + (cnt% pageSize >0?1:0);
		if(end>cnt)end=cnt;
		number=cnt-(currentPage-1)*pageSize; //출력용 글번호
		if(cnt>0) { 
			ArrayList<GuestVO> adboard=dao.getAdminList(start, end,admin);
			req.setAttribute("adboard", adboard);
			if(req.getParameter("boardselect")==null) {	
				ArrayList<GuestVO> dtos=dao.getBoardList(start, end,admin);
				req.setAttribute("dtos", dtos);
			}else {
				 board=req.getParameter("findboard");
				 boardselect=req.getParameter("boardselect");
				ArrayList<GuestVO> dtos=dao.boardsearch(start,end,board,boardselect);
				req.setAttribute("dtos", dtos);
			}
		}
		startPage=(currentPage/pageBlock)*pageBlock+1;
		if(currentPage % pageBlock ==0) startPage-=pageBlock;
		endPage=startPage+pageBlock-1;
		if(endPage> pageCount)endPage=pageCount;
		req.setAttribute("cnt", cnt);	//글갯수
		req.setAttribute("number", number);	//출력용 글번호
		req.setAttribute("pageNum", pageNum); //페이지 번호
		if(cnt>0) {
			req.setAttribute("startPage", startPage);	//시작페이지
			req.setAttribute("endPage", endPage);	//마지막 페이지
			req.setAttribute("pageBlock", pageBlock);	//출력할 페이지 갯수
			req.setAttribute("pageCount", pageCount);	//페이지 갯수
			req.setAttribute("currentPage", currentPage);	//현재 페이지
			req.setAttribute("findboard", board);	//시작페이지
			req.setAttribute("boardselect", boardselect);	//시작페이지
		}	
	}
	@Override
	public void boardread(HttpServletRequest req, HttpServletResponse res) {
				int boardnum= Integer.parseInt(req.getParameter("boardnum"));
				int pageNum=Integer.parseInt(req.getParameter("pageNum"));
				int number=Integer.parseInt(req.getParameter("number"));
				GuestDAO dao=GuestDAOImpl.getInstance();
				int updateCnt=dao.addReadCnt(boardnum);
				GuestVO vo=dao.getArticle(boardnum);
				req.setAttribute("vo", vo);
				req.setAttribute("pageNum", pageNum);
				req.setAttribute("number", number);
		}
	@Override
	public String search(HttpServletRequest req, HttpServletResponse res) {
				String bookname=req.getParameter("findbook");
				String bookselect=req.getParameter("bookselect");
				HostDAO dao=HostDAOImpl.getInstance();
				int cnt=0; //글 갯수
				int imgcnt=0;
				if(req.getParameter("bookselect")==null) {
					cnt=dao.getBookCnt();
				}
				else {
					cnt=dao.getSearchCnt(req.getParameter("findbook"),req.getParameter("bookselect"));			
				}
				if(req.getParameter("bookimg")!=null) {
					imgcnt=dao.getSearchImgCnt(req.getParameter("bookimg"));
					cnt=imgcnt;
				}
				int pageSize=10; //한 페이지당 출력할 글 갯수
				int pageBlock=3; //한 블럭당 페이지 갯수
				int start=0; //현재 페이지 시작 글번호
				int end=0; //현재 페이지 마지막 글번호
				int number=0; //출력용 글번호
				String pageNum=null; //페이지 번호
				int currentPage=0; //현재페이지
				int pageCount=0; //페이지 갯수
				int startPage=0; //시작페이지
				int endPage=0; //마지막페이지
				pageNum=req.getParameter("pageNum");
				if(pageNum==null) {
					pageNum="1";
				}
				currentPage=Integer.parseInt(pageNum);
				pageCount=(cnt/ pageSize) + (cnt% pageSize >0?1:0);
				start=(currentPage-1)* pageSize+1;
				end=start+pageSize-1;
				if(end>cnt)end=cnt;
				number=cnt-(currentPage-1)*pageSize; //출력용 글번호
				startPage=(currentPage/pageBlock)*pageBlock+1;		//1
				if(currentPage % pageBlock ==0) startPage-=pageBlock;
				endPage=startPage+pageBlock-1;//3
				if(endPage> pageCount)endPage=pageCount; //2
				if(cnt>0) {
					if(bookselect!=null) {
						ArrayList<HostVO> dtos=dao.booksearch(start,end,bookname,bookselect);
						req.setAttribute("dtos", dtos);
					}else {
						ArrayList<HostVO> dtos=dao.booksearch(start,end,Integer.parseInt(req.getParameter("booknum")));
						req.setAttribute("dtos", dtos);
					}
				}
				req.setAttribute("cnt", cnt);	//글갯수
				req.setAttribute("number", number);	//출력용 글번호
				req.setAttribute("pageNum", pageNum); //페이지 번호
				if(cnt>0) {
					req.setAttribute("startPage", startPage);	//시작페이지
					req.setAttribute("endPage", endPage);	//마지막 페이지
					req.setAttribute("pageBlock", pageBlock);	//출력할 페이지 갯수
					req.setAttribute("pageCount", pageCount);	//페이지 갯수
					req.setAttribute("currentPage", currentPage);	//현재 페이지
					req.setAttribute("findbook", bookname);
					req.setAttribute("bookselect", bookselect);
				}
			return "/jsp/guest/book_info.jsp";
	}
	@Override
	public String cartadd(HttpServletRequest req, HttpServletResponse res) {
		MultipartRequest mr=null;
		int maxsize=10*1024*1024;
		String saveDir=req.getRealPath("/images/");
		String realDir="C:\\Users\\Hyeonmo\\Downloads\\java\\eclipse-jee-2018-09-win32-x86_64\\workspace\\Test\\WebContent\\images\\";
		String encType="UTF-8";
		int cnt=0;
		try {
			mr=new MultipartRequest(req,saveDir,maxsize,encType,new DefaultFileRenamePolicy());
			FileInputStream fis= new FileInputStream(saveDir+mr.getParameter("bookimg"));		
			FileOutputStream fos=new FileOutputStream(realDir+mr.getParameter("bookimg"));
			int data=0;
			while((data=fis.read())!=-1) {
				fos.write(data);
			}
			fis.close();
			fos.close();		
			String[] booknum=mr.getParameterValues("check");
			String userid=(String)req.getSession().getAttribute("userid");
			HostDAO dao=HostDAOImpl.getInstance();
			for(int i=0;i<booknum.length;i++) {
			HostVO vo=dao.bookdb(Integer.parseInt(booknum[i]));
			HostVO cart=dao.cartfind(Integer.parseInt(booknum[i]));
				if(cart.getBooknum()!=Integer.parseInt(booknum[i])) {
					dao.inputcart(vo,userid);	
					cnt=1;
				}else {
					cnt=0;
				}
			}
			req.setAttribute("cnt", cnt);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return "/jsp/guest/cartPro.jsp";
	}
	@Override
	public String orderadd(HttpServletRequest req, HttpServletResponse res) {
		MultipartRequest mr=null;
		int maxsize=10*1024*1024;
		String saveDir=req.getRealPath("/images/");
		String realDir="C:\\Users\\Hyeonmo\\Downloads\\java\\eclipse-jee-2018-09-win32-x86_64\\workspace\\Test\\WebContent\\images\\";
		String encType="UTF-8";
		int cnt=1;
		int buycnt=1;
		try {
			mr=new MultipartRequest(req,saveDir,maxsize,encType,new DefaultFileRenamePolicy());
			FileInputStream fis= new FileInputStream(saveDir+mr.getParameter("bookimg"));		
			FileOutputStream fos=new FileOutputStream(realDir+mr.getParameter("bookimg"));
			int data=0;
			while((data=fis.read())!=-1) {
				fos.write(data);
			}
			fis.close();
			fos.close();	
			String userid=(String)req.getSession().getAttribute("userid");
			String[] cartnum=mr.getParameterValues("check");
			String[] temp=new String[cartnum.length+1];
			for(int i=0;i<cartnum.length;i++) {
				temp[i]="1";
			}
			String[] bookcount=(mr.getParameterValues("bookcount")==null)?temp:mr.getParameterValues("bookcount");
			String receiver=mr.getParameter("receiver");
			String re_phone=mr.getParameter("re_phone");
			String re_post=mr.getParameter("re_post");
			String message=mr.getParameter("message");
			String orderstate="결제요청";
			String name="guest";
			HostVO vo=null;
			HostDAO dao=HostDAOImpl.getInstance();
			HostVO nowbuy=null;
			for(int i=0;i<cartnum.length;i++) {
				vo=dao.cartdb(Integer.parseInt(cartnum[i]));	// 카트의 도서 정보
				vo.setBookcount(Integer.parseInt(bookcount[i]));
				nowbuy=dao.bookdb(Integer.parseInt(cartnum[i]));
				nowbuy.setCartnum(0);
				nowbuy.setOrderstate(orderstate);
				nowbuy.setBookcount(Integer.parseInt(bookcount[i]));	
				vo.setOrderstate(orderstate);
				vo.setReceiver(receiver);
				vo.setRe_phone(re_phone);
				vo.setRe_post(re_post);
				vo.setMessage(message);
				HostVO order=dao.orderfind(vo.getBooknum());	//주문목록에서의 책이 존재하는지 확인
				HostVO book=dao.bookdb(vo.getBooknum());
				HostVO buybook=dao.bookdb(nowbuy.getBooknum());
				if(vo.getBooknum()==0) {
					if(order.getBooknum()!=nowbuy.getBooknum()) {		//바로구매
						dao.inputOrder(nowbuy,userid);
						buycnt=dao.setbcount(buybook, Integer.parseInt(bookcount[i]),name);
						if(buybook.getBookcount()>(Integer.parseInt(bookcount[i])+order.getBookcount())) {
							int inorder=dao.setordercount(order,Integer.parseInt(bookcount[i])+order.getBookcount());		//주문목록에 도서수량 추가
							if(inorder==0) {
								dao.inputOrder(nowbuy,userid);
							}
						}else {
							buycnt=0;
						}
					}
					req.setAttribute("buycnt", buycnt);
				}else {
					if(order.getBooknum()!=vo.getBooknum()) {
						dao.inputOrder(vo,userid);
						cnt=dao.setbcount(book, Integer.parseInt(bookcount[i]),name);
						System.out.println("장바구니:"+cnt);
						if(cnt==1) {
							dao.deletecart(vo, userid);
						}
					}else {
						if(book.getBookcount()>(Integer.parseInt(bookcount[i])+order.getBookcount())) {
							dao.deletecart(vo, userid);							
							int inorder=dao.setordercount(order,Integer.parseInt(bookcount[i])+order.getBookcount());		//주문목록에 도서수량 추가
							if(inorder==0) {
								dao.inputOrder(vo,userid);
							}
						}else {
							cnt=0;
						}
					}
				}
				req.setAttribute("cnt", cnt);
			}	
			req.setAttribute("vo", vo);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return "/jsp/guest/orderPro.jsp";
	}
	@Override
	public String cartlist(HttpServletRequest req, HttpServletResponse res) {
		int pageSize=10; //한 페이지당 출력할 글 갯수
		int pageBlock=3; //한 블럭당 페이지 갯수
		int cnt=0; //글 갯수
		int start=0; //현재 페이지 시작 글번호
		int end=0; //현재 페이지 마지막 글번호
		int number=0; //출력용 글번호
		String pageNum=null; //페이지 번호
		int currentPage=0; //현재페이지
		int pageCount=0; //페이지 갯수
		int startPage=0; //시작페이지
		int endPage=0; //마지막페이지
		String id=(String)req.getSession().getAttribute("userid");
		HostDAO dao=HostDAOImpl.getInstance();
		cnt=dao.getCartCnt();
		pageNum=req.getParameter("pageNum");
		if(pageNum==null) {
			pageNum="1";
		}
		currentPage=Integer.parseInt(pageNum);
		pageCount=(cnt/ pageSize) + (cnt% pageSize >0?1:0);
		start=(currentPage-1)* pageSize+1;
		//현재 페이지 끝번호
		end=start+pageSize-1;
		if(end>cnt)end=cnt;
		number=cnt-(currentPage-1)*pageSize; //출력용 글번호
		if(cnt>0) {
			ArrayList<HostVO> dtos=dao.getCartList(start, end,id);
			req.setAttribute("dtos", dtos);
			GuestDAO gdao=GuestDAOImpl.getInstance();
			GuestVO address=gdao.getAddress(id);
			req.setAttribute("address", address);
		}
		startPage=(currentPage/pageBlock)*pageBlock+1;
		if(currentPage % pageBlock ==0) startPage-=pageBlock;
		endPage=startPage+pageBlock-1;
		if(endPage> pageCount)endPage=pageCount;
		req.setAttribute("cnt", cnt);	//글갯수
		req.setAttribute("number", number);	//출력용 글번호
		req.setAttribute("pageNum", pageNum); //페이지 번호
		if(cnt>0) {
			req.setAttribute("startPage", startPage);	//시작페이지
			req.setAttribute("endPage", endPage);	//마지막 페이지
			req.setAttribute("pageBlock", pageBlock);	//출력할 페이지 갯수
			req.setAttribute("pageCount", pageCount);	//페이지 갯수
			req.setAttribute("currentPage", currentPage);	//현재 페이지
		}
		return "/jsp/guest/cart.jsp";
	}	
	@Override
	public void orderlist(HttpServletRequest req, HttpServletResponse res) {
		int pageSize=10; //한 페이지당 출력할 글 갯수
		int pageBlock=3; //한 블럭당 페이지 갯수
		int cnt=0; //글 갯수
		int start=0; //현재 페이지 시작 글번호
		int end=0; //현재 페이지 마지막 글번호
		int number=0; //출력용 글번호
		String pageNum=null; //페이지 번호
		int currentPage=0; //현재페이지
		int pageCount=0; //페이지 갯수
		int startPage=0; //시작페이지
		int endPage=0; //마지막페이지
		String id=(String)req.getSession().getAttribute("userid");
		HostDAO dao=HostDAOImpl.getInstance();
		cnt=dao.getOrderCnt(id);
		pageNum=req.getParameter("pageNum");
		if(pageNum==null) {
			pageNum="1";
		}
		currentPage=Integer.parseInt(pageNum);
		pageCount=(cnt/ pageSize) + (cnt% pageSize >0?1:0);
		start=(currentPage-1)* pageSize+1;
		end=start+pageSize-1;
		if(end>cnt)end=cnt;
		number=cnt-(currentPage-1)*pageSize; //출력용 글번호
		if(cnt>0) {
			ArrayList<HostVO> dtos=dao.getOrderList(id);	
			req.setAttribute("dtos", dtos);
		}
		startPage=(currentPage/pageBlock)*pageBlock+1;
		if(currentPage % pageBlock ==0) startPage-=pageBlock;
		endPage=startPage+pageBlock-1;
		if(endPage> pageCount)endPage=pageCount;
		req.setAttribute("cnt", cnt);	//글갯수
		req.setAttribute("number", number);	//출력용 글번호
		req.setAttribute("pageNum", pageNum); //페이지 번호
		if(cnt>0) {
			req.setAttribute("startPage", startPage);	//시작페이지
			req.setAttribute("endPage", endPage);	//마지막 페이지
			req.setAttribute("pageBlock", pageBlock);	//출력할 페이지 갯수
			req.setAttribute("pageCount", pageCount);	//페이지 갯수
			req.setAttribute("currentPage", currentPage);	//현재 페이지
		}			
	}
	@Override
	public String cartdelete(HttpServletRequest req, HttpServletResponse res) {
		MultipartRequest mr=null;
		int maxsize=10*1024*1024;
		String saveDir=req.getRealPath("/images/");
		String realDir="C:\\Users\\Hyeonmo\\Downloads\\java\\eclipse-jee-2018-09-win32-x86_64\\workspace\\Test\\WebContent\\images\\";
		String encType="UTF-8";
		try {
			mr=new MultipartRequest(req,saveDir,maxsize,encType,new DefaultFileRenamePolicy());
			FileInputStream fis= new FileInputStream(saveDir+mr.getParameter("bookimg"));		
			FileOutputStream fos=new FileOutputStream(realDir+mr.getParameter("bookimg"));
			int data=0;
			while((data=fis.read())!=-1) {
				fos.write(data);
			}
			fis.close();
			fos.close();	
			String[] cartnum=mr.getParameterValues("check");
			for(int i=0;i<cartnum.length;i++) {
				HostDAO dao=HostDAOImpl.getInstance();
				HostVO cart=dao.cartnumfind(Integer.parseInt(cartnum[i]));
				dao.deletecart(cart);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return "/jsp/guest/cartPro.jsp";
	}
	@Override
	public void confirmOklist(HttpServletRequest req, HttpServletResponse res) {
		int pageSize=10; //한 페이지당 출력할 글 갯수
		int pageBlock=3; //한 블럭당 페이지 갯수
		int cnt=0; //글 갯수
		int start=0; //현재 페이지 시작 글번호
		int end=0; //현재 페이지 마지막 글번호
		int number=0; //출력용 글번호
		String pageNum=null; //페이지 번호
		int currentPage=0; //현재페이지
		int pageCount=0; //페이지 갯수
		int startPage=0; //시작페이지
		int endPage=0; //마지막페이지
		String state="결제승인";
		String id=(String)req.getSession().getAttribute("userid");
		HostDAO dao=HostDAOImpl.getInstance();
		cnt=dao.getRefundCnt(state,id);
		pageNum=req.getParameter("pageNum");
		if(pageNum==null) {
			pageNum="1";
		}
		currentPage=Integer.parseInt(pageNum);
		pageCount=(cnt/ pageSize) + (cnt% pageSize >0?1:0);
		start=(currentPage-1)* pageSize+1;
		end=start+pageSize-1;
		if(end>cnt)end=cnt;
		number=cnt-(currentPage-1)*pageSize; //출력용 글번호
		if(cnt>0) {
			ArrayList<HostVO> dtos=dao.getRefundList(start, end,state,id);
			req.setAttribute("dtos", dtos);
		}
		startPage=(currentPage/pageBlock)*pageBlock+1;
		if(currentPage % pageBlock ==0) startPage-=pageBlock;
		endPage=startPage+pageBlock-1;
		if(endPage> pageCount)endPage=pageCount;
		req.setAttribute("cnt", cnt);	//글갯수
		req.setAttribute("number", number);	//출력용 글번호
		req.setAttribute("pageNum", pageNum); //페이지 번호
		if(cnt>0) {
			req.setAttribute("startPage", startPage);	//시작페이지
			req.setAttribute("endPage", endPage);	//마지막 페이지
			req.setAttribute("pageBlock", pageBlock);	//출력할 페이지 갯수
			req.setAttribute("pageCount", pageCount);	//페이지 갯수
			req.setAttribute("currentPage", currentPage);	//현재 페이지
		}			
	}
	@Override
	public void refund(HttpServletRequest req, HttpServletResponse res) {
		MultipartRequest mr=null;
		int maxsize=10*1024*1024;
		String saveDir=req.getRealPath("/images/");
		String realDir="C:\\Users\\Hyeonmo\\Downloads\\java\\eclipse-jee-2018-09-win32-x86_64\\workspace\\Test\\WebContent\\images\\";
		String encType="UTF-8";
		try {
			mr=new MultipartRequest(req,saveDir,maxsize,encType,new DefaultFileRenamePolicy());
			FileInputStream fis= new FileInputStream(saveDir+mr.getParameter("bookimg"));		
			FileOutputStream fos=new FileOutputStream(realDir+mr.getParameter("bookimg"));
			int data=0;
			while((data=fis.read())!=-1) {
				fos.write(data);
			}
			fis.close();
			fos.close();
			String[] ordernum=mr.getParameterValues("check");
			String orderstate="환불요청";
			HostVO vo=new HostVO();
			for(int i=0;i<ordernum.length;i++) {
				vo.setOrdernum(Integer.parseInt(ordernum[i]));
				vo.setOrderstate(orderstate);
				HostDAO dao=HostDAOImpl.getInstance();
				dao.changeorder(orderstate,Integer.parseInt(ordernum[i]));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	@Override
	public String boardwrite(HttpServletRequest req, HttpServletResponse res) {
		int boardnum=0;
		int pageNum=0;
		if(req.getParameter("boardnum") !=null) {
			boardnum=Integer.parseInt(req.getParameter("boardnum"));	
		}
		pageNum=Integer.parseInt(req.getParameter("pageNum"));	
		req.setAttribute("pageNum", pageNum);
		req.setAttribute("boardnum", boardnum);
		return "/jsp/guest/board_write.jsp";
	}
	@Override
	public String boardinsert(HttpServletRequest req, HttpServletResponse res) {
		int boardnum=Integer.parseInt(req.getParameter("boardnum"));
		String pageNum=req.getParameter("pageNum");
		String id=req.getParameter("id");
		String pwd=req.getParameter("pwd");
		String content=req.getParameter("content");
		String subject=req.getParameter("subject");
		GuestDAO dao=GuestDAOImpl.getInstance();
		GuestVO vo=new GuestVO();
		vo.setBoardnum(boardnum);
		vo.setId(id);
		vo.setPwd(pwd);
		vo.setContent(content);
		vo.setSubject(subject);
		int updatecnt=dao.insertBoard(vo);
		req.setAttribute("pageNum", pageNum);
		req.setAttribute("boardnum", boardnum);
		req.setAttribute("cnt", updatecnt);
		return "/jsp/guest/boardPro.jsp";
	}
	@Override
	public String boardmodify(HttpServletRequest req, HttpServletResponse res) {
		String pwd=req.getParameter("pwd");
		int boardnum=Integer.parseInt(req.getParameter("boardnum"));
		int pageNum=Integer.parseInt(req.getParameter("pageNum"));
		GuestDAO dao=GuestDAOImpl.getInstance();
		int checkcnt=dao.numPwdCheck(boardnum, pwd);
		GuestVO vo=null;
			if(checkcnt==1) {
				vo=dao.getBoard(boardnum);
			}		
			req.setAttribute("vo", vo);
			req.setAttribute("pageNum", pageNum);
			req.setAttribute("boardnum", boardnum);
			req.setAttribute("cnt", checkcnt);
		return "/jsp/guest/bm_view.jsp";
	}
	@Override
	public String bmPro(HttpServletRequest req, HttpServletResponse res) {
		int boardnum=Integer.parseInt(req.getParameter("boardnum"));
		int pageNum=Integer.parseInt(req.getParameter("pageNum"));
		String subject=req.getParameter("subject");
		String content=req.getParameter("content");
		GuestDAO dao=GuestDAOImpl.getInstance();
		GuestVO vo=new GuestVO();
		vo.setBoardnum(boardnum);
		int updatecnt=dao.updateBoard(subject,content,boardnum);
		req.setAttribute("vo", vo);
		req.setAttribute("pageNum", pageNum);
		req.setAttribute("boardnum", boardnum);
		req.setAttribute("cnt", updatecnt);
		return "/jsp/guest/boardPro.jsp";
	}
	@Override
	public String boarddelete(HttpServletRequest req, HttpServletResponse res) {
		String pwd=req.getParameter("pwd");
		int boardnum=Integer.parseInt(req.getParameter("boardnum"));
		int pageNum=Integer.parseInt(req.getParameter("pageNum"));
		GuestDAO dao=GuestDAOImpl.getInstance();
		int checkcnt=dao.numPwdCheck(boardnum, pwd);
		GuestVO vo=new GuestVO();
		int deletecnt=0;
			if(checkcnt==1) {
				 deletecnt=dao.deleteBoard(boardnum);
			}		
			req.setAttribute("vo", vo);
			req.setAttribute("pageNum", pageNum);
			req.setAttribute("boardnum", boardnum);
			req.setAttribute("cnt", deletecnt);
		return "/jsp/guest/boardPro.jsp";
	}
	@Override
	public void deallist(HttpServletRequest req, HttpServletResponse res) {
		int list=0;
		if(req.getParameter("finddeal")==null) {
			list=1;
		}
		int pageSize=5; //한 페이지당 출력할 글 갯수
		int pageBlock=3; //한 블럭당 페이지 갯수
		int cnt=0; //글 갯수
		int start=0; //현재 페이지 시작 글번호
		int end=0; //현재 페이지 마지막 글번호
		int number=0; //출력용 글번호
		String pageNum=null; //페이지 번호
		int currentPage=0; //현재페이지
		int pageCount=0; //페이지 갯수
		int startPage=0; //시작페이지
		int endPage=0; //마지막페이지
		GuestDAO dao=GuestDAOImpl.getInstance();
		cnt=dao.getDealCnt();
		pageNum=req.getParameter("pageNum");
		if(pageNum==null) {
			pageNum="1";
		}
		//글 30건 기준
		currentPage=Integer.parseInt(pageNum);
		//페이지 갯수 6
		pageCount=(cnt/ pageSize) + (cnt% pageSize >0?1:0);
		//현재 페이지 시작 글번호 1(페이지별)
		start=(currentPage-1)* pageSize+1;
		//현재 페이지 끝번호
		end=start+pageSize-1;
		if(end>cnt)end=cnt;
		//출력용 글번호
		number=cnt-(currentPage-1)*pageSize; //출력용 글번호
		if(cnt>0) {
			//5-2게시글 목록 조회
			if(list==1) {
				ArrayList<GuestVO> dtos=dao.getDealList(start, end);
				req.setAttribute("dtos", dtos);
			}else {
				String deal=req.getParameter("finddeal");
				String dealselect=req.getParameter("dealselect");
				ArrayList<GuestVO> dtos=dao.dealsearch(start,end,deal,dealselect);
				req.setAttribute("dtos", dtos);
			}
		}
		//6 request session에 처리 결과를 저장(jsp에 전달하기 위함)
		//시작페이지
		startPage=(currentPage/pageBlock)*pageBlock+1;
		if(currentPage % pageBlock ==0) startPage-=pageBlock;
		//마지막페이지
		endPage=startPage+pageBlock-1;
		if(endPage> pageCount)endPage=pageCount;
		req.setAttribute("cnt", cnt);	//글갯수
		req.setAttribute("number", number);	//출력용 글번호
		req.setAttribute("pageNum", pageNum); //페이지 번호
		if(cnt>0) {
			req.setAttribute("startPage", startPage);	//시작페이지
			req.setAttribute("endPage", endPage);	//마지막 페이지
			req.setAttribute("pageBlock", pageBlock);	//출력할 페이지 갯수
			req.setAttribute("pageCount", pageCount);	//페이지 갯수
			req.setAttribute("currentPage", currentPage);	//현재 페이지
		}			
	}

	public void dealinsert(HttpServletRequest req, HttpServletResponse res) {
		String pageNum=req.getParameter("pageNum");
		MultipartRequest mr=null;
		int maxsize=10*1024*1024;
		String saveDir=req.getRealPath("/images/");
		String realDir="C:\\Users\\Hyeonmo\\Downloads\\java\\eclipse-jee-2018-09-win32-x86_64\\workspace\\Test\\WebContent\\images\\";
		String encType="UTF-8";
		try {
			mr=new MultipartRequest(req,saveDir,maxsize,encType,new DefaultFileRenamePolicy());
			FileInputStream fis= new FileInputStream(saveDir+mr.getFilesystemName("dealimg"));
			FileOutputStream fos=new FileOutputStream(realDir+mr.getFilesystemName("dealimg"));
			int data=0;
			while((data=fis.read())!=-1) {
				fos.write(data);
			}
			fis.close();
			fos.close();
			String dealimg=mr.getFilesystemName("dealimg");
			String dealname=mr.getParameter("dealname");
			String dealhow=mr.getParameter("dealhow");
			String dealplace=mr.getParameter("dealplace1")+mr.getParameter("dealplace2");
			String category=mr.getParameter("category");
			int dealprice=Integer.parseInt(mr.getParameter("dealprice"));
			String id=(String)req.getSession().getAttribute("userid");
			String seller=null;
			if(id!=null) {
				 seller=mr.getParameter("seller");	
			}else {
				String hp1=mr.getParameter("hp1");
				String hp2=mr.getParameter("hp2");
				String hp3=mr.getParameter("hp3");
				seller=hp1+hp2+hp3;
			}
			String dealstate="거래 중";
			GuestDAO dao=GuestDAOImpl.getInstance();
			GuestVO vo=new GuestVO();
			vo.setSeller(seller);
			vo.setDealimg(dealimg);
			vo.setDealname(dealname);
			vo.setDealhow(dealhow);
			vo.setDealplace(dealplace);
			vo.setCategory(category);
			vo.setDealprice(dealprice);
			vo.setDealstate(dealstate);
			int updatecnt=dao.insertDeal(vo);
			req.setAttribute("pageNum", pageNum);
			req.setAttribute("cnt", updatecnt);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	@Override
	public void dealregister(HttpServletRequest req, HttpServletResponse res) {
		int dealnum=1;
		int pageNum=0;
		if(req.getParameter("dealnum") !=null) {
			dealnum=Integer.parseInt(req.getParameter("dealnum"));	
		}
		pageNum=Integer.parseInt(req.getParameter("pageNum"));	
		req.setAttribute("pageNum", pageNum);
		req.setAttribute("dealnum", dealnum);
	}

	@Override
	public void dealread(HttpServletRequest req, HttpServletResponse res) {
		int dealnum= Integer.parseInt(req.getParameter("dealnum"));
		int pageNum=Integer.parseInt(req.getParameter("pageNum"));
		int number=Integer.parseInt(req.getParameter("number"));
		GuestDAO dao=GuestDAOImpl.getInstance();
		int updateCnt=dao.addDealCnt(dealnum);
		GuestVO vo=dao.getDeal(dealnum);
		req.setAttribute("vo", vo);
		req.setAttribute("pageNum", pageNum);
		req.setAttribute("number", number);
		req.setAttribute("cnt", updateCnt);
	}
	@Override
	public void dealrequest(HttpServletRequest req, HttpServletResponse res) {
		int dealnum=1;
		int pageNum=0;
		if(req.getParameter("dealnum") !=null) {
			dealnum=Integer.parseInt(req.getParameter("dealnum"));	
		}
		pageNum=Integer.parseInt(req.getParameter("pageNum"));	
		req.setAttribute("pageNum", pageNum);
		req.setAttribute("dealnum", dealnum);
	}
	@Override
	public void dqinsert(HttpServletRequest req, HttpServletResponse res) {
		int dealnum=Integer.parseInt(req.getParameter("dealnum"));
		String pageNum=req.getParameter("pageNum");
		String dealimg=req.getParameter("dealimg");
		String dealname=req.getParameter("dealname");
		int requestprice=Integer.parseInt(req.getParameter("requestprice"));
		String message=req.getParameter("message");
		String requeststate="요청";
		String buyer=req.getParameter("buyer");
		String seller=req.getParameter("seller");
		GuestDAO dao=GuestDAOImpl.getInstance();
		GuestVO vo=new GuestVO();
		vo.setDealnum(dealnum);
		vo.setBuyer(buyer);
		vo.setSeller(seller);
		vo.setDealimg(dealimg);
		vo.setDealname(dealname);
		vo.setRequestprice(requestprice);
		vo.setMessage(message);
		vo.setRequeststate(requeststate);
		int updatecnt=dao.insertrequest(vo);
		req.setAttribute("pageNum", pageNum);
		req.setAttribute("cnt", updatecnt);
	}
	@Override
	public void notelist(HttpServletRequest req, HttpServletResponse res) {
		int pageSize=10; //한 페이지당 출력할 글 갯수
		int pageBlock=3; //한 블럭당 페이지 갯수
		int cnt=0; //글 갯수
		int start=0; //현재 페이지 시작 글번호
		int end=0; //현재 페이지 마지막 글번호
		int number=0; //출력용 글번호
		String pageNum=null; //페이지 번호
		int currentPage=0; //현재페이지
		int pageCount=0; //페이지 갯수
		int startPage=0; //시작페이지
		int endPage=0; //마지막페이지
		String id=(String)req.getSession().getAttribute("userid");
		GuestDAO dao=GuestDAOImpl.getInstance();
		cnt=dao.getNoteCnt();
		pageNum=req.getParameter("pageNum");
		if(pageNum==null) {
			pageNum="1";
		}
		currentPage=Integer.parseInt(pageNum);
		pageCount=(cnt/ pageSize) + (cnt% pageSize >0?1:0);
		start=(currentPage-1)* pageSize+1;
		end=start+pageSize-1;
		if(end>cnt)end=cnt;
		number=cnt-(currentPage-1)*pageSize; //출력용 글번호
		if(cnt>0) {
			ArrayList<GuestVO> dtos=dao.getNoteList(start, end,id);
			req.setAttribute("dtos", dtos);
		}
		startPage=(currentPage/pageBlock)*pageBlock+1;
		if(currentPage % pageBlock ==0) startPage-=pageBlock;
		endPage=startPage+pageBlock-1;
		if(endPage> pageCount)endPage=pageCount;
		req.setAttribute("cnt", cnt);	//글갯수
		req.setAttribute("number", number);	//출력용 글번호
		req.setAttribute("pageNum", pageNum); //페이지 번호
		if(cnt>0) {
			req.setAttribute("startPage", startPage);	//시작페이지
			req.setAttribute("endPage", endPage);	//마지막 페이지
			req.setAttribute("pageBlock", pageBlock);	//출력할 페이지 갯수
			req.setAttribute("pageCount", pageCount);	//페이지 갯수
			req.setAttribute("currentPage", currentPage);	//현재 페이지
		}			
	}
	@Override
	public void requestok(HttpServletRequest req, HttpServletResponse res) {
		int requestnum=Integer.parseInt(req.getParameter("requestnum"));
		int dealnum=Integer.parseInt(req.getParameter("dealnum"));
		String requeststate="수락";
		String dealstate="거래완료";
		GuestVO vo=new GuestVO();
		vo.setDealnum(dealnum);
		vo.setDealstate(dealstate);
		vo.setRequestnum(requestnum);
		vo.setRequeststate(requeststate);
		GuestDAO dao=GuestDAOImpl.getInstance();
		dao.deleterequest(vo);
		dao.changedeal(vo);
	}
	@Override
	public void requestno(HttpServletRequest req, HttpServletResponse res) {
		int requestnum=Integer.parseInt(req.getParameter("requestnum"));
		int dealnum=Integer.parseInt(req.getParameter("dealnum"));
		String requeststate="거절";
		GuestVO vo=new GuestVO();
		vo.setDealnum(dealnum);
		vo.setRequestnum(requestnum);
		vo.setRequeststate(requeststate);
		GuestDAO dao=GuestDAOImpl.getInstance();
		dao.deleterequest(vo);
	}
	@Override
	public void noteread(HttpServletRequest req, HttpServletResponse res) {
				int requestnum= Integer.parseInt(req.getParameter("requestnum"));
				int pageNum=Integer.parseInt(req.getParameter("pageNum"));
				int number=Integer.parseInt(req.getParameter("number"));
				GuestDAO dao=GuestDAOImpl.getInstance();
				GuestVO vo=dao.getNote(requestnum);
				req.setAttribute("vo", vo);
				req.setAttribute("pageNum", pageNum);
				req.setAttribute("number", number);
	}
	@Override
	public void addcomment(HttpServletRequest req, HttpServletResponse res) {
		int boardnum=Integer.parseInt(req.getParameter("boardnum"));
		String commentid=req.getParameter("commentid");
		String content=req.getParameter("content");
		String pageNum=req.getParameter("pageNum");
		GuestVO vo=new GuestVO();
		vo.setBoardnum(boardnum);
		vo.setCommentid(commentid);
		vo.setContent(content);
		GuestDAO dao=GuestDAOImpl.getInstance();
		int commentnum=dao.insertcomment(vo);
		req.setAttribute("pageNum", pageNum);
		req.setAttribute("commentid", commentid);
		req.setAttribute("content", content);
		req.setAttribute("cnt", commentnum);
	}
	@Override
	public void commentlist(HttpServletRequest req, HttpServletResponse res) {
		int pageSize=5; //한 페이지당 출력할 글 갯수
		int pageBlock=3; //한 블럭당 페이지 갯수
		int cnt=0; //글 갯수
		int start=0; //현재 페이지 시작 글번호
		int end=0; //현재 페이지 마지막 글번호
		int number=0; //출력용 글번호
		String pageNum=null; //페이지 번호
		int currentPage=0; //현재페이지
		int pageCount=0; //페이지 갯수
		int startPage=0; //시작페이지
		int endPage=0; //마지막페이지
		GuestDAO dao=GuestDAOImpl.getInstance();
		int boardnum=Integer.parseInt(req.getParameter("boardnum"));
		cnt=dao.getCommentCnt(boardnum);
		pageNum=req.getParameter("pageNum");
		if(pageNum==null) {
			pageNum="1";
		}
		currentPage=Integer.parseInt(pageNum);
		pageCount=(cnt/ pageSize) + (cnt% pageSize >0?1:0);
		start=(currentPage-1)* pageSize+1;
		end=start+pageSize-1;
		if(end>cnt)end=cnt;
		number=cnt-(currentPage-1)*pageSize; //출력용 글번호
		if(cnt>0) {
			//5-2게시글 목록 조회
			ArrayList<GuestVO> dtos=dao.getCommentList(start,end, boardnum);
			req.setAttribute("dtos", dtos);
		}
		startPage=(currentPage/pageBlock)*pageBlock+1;
		if(currentPage % pageBlock ==0) startPage-=pageBlock;
		endPage=startPage+pageBlock-1;
		if(endPage> pageCount)endPage=pageCount;
		req.setAttribute("cnt", cnt);	//글갯수
		req.setAttribute("number", number);	//출력용 글번호
		req.setAttribute("pageNum", pageNum); //페이지 번호
		if(cnt>0) {
			req.setAttribute("startPage", startPage);	//시작페이지
			req.setAttribute("endPage", endPage);	//마지막 페이지
			req.setAttribute("pageBlock", pageBlock);	//출력할 페이지 갯수
			req.setAttribute("pageCount", pageCount);	//페이지 갯수
			req.setAttribute("currentPage", currentPage);	//현재 페이지
		}			
	}
	
	@Override
	public String findid(HttpServletRequest req, HttpServletResponse res) {
		String findemail=req.getParameter("findemail");
		String findphone=req.getParameter("findphone");
		GuestDAO dao=GuestDAOImpl.getInstance();
		String id=dao.matchid(findemail,findphone);
		req.setAttribute("id", id);
		return "/jsp/guest/findidPro.jsp";
	}
	@Override
	public String findpwd(HttpServletRequest req, HttpServletResponse res) {
		String findid=req.getParameter("findid");
		String findemail=req.getParameter("findemail");
		String findphone=req.getParameter("findphone");
		GuestDAO dao=GuestDAOImpl.getInstance();
		String pwd=dao.matchpwd(findid,findemail,findphone);
		req.setAttribute("pwd", pwd);
		return "/jsp/guest/findpwdPro.jsp";
	}
	@Override
	public String showbook(HttpServletRequest req, HttpServletResponse res) {
		int pageSize=10; //한 페이지당 출력할 글 갯수
		int pageBlock=3; //한 블럭당 페이지 갯수
		int cnt=0; //글 갯수
		int start=0; //현재 페이지 시작 글번호
		int end=0; //현재 페이지 마지막 글번호
		int number=0; //출력용 글번호
		String pageNum=null; //페이지 번호
		int currentPage=0; //현재페이지
		int pageCount=0; //페이지 갯수
		int startPage=0; //시작페이지
		int endPage=0; //마지막페이지
		HostDAO dao=HostDAOImpl.getInstance();
		cnt=dao.getBookCnt();
		pageNum=req.getParameter("pageNum");
		if(pageNum==null) {
			pageNum="1";
		}
		currentPage=Integer.parseInt(pageNum);
		pageCount=(cnt/ pageSize) + (cnt% pageSize >0?1:0);
		start=(currentPage-1)* pageSize+1;
		end=start+pageSize-1;
		if(end>cnt)end=cnt;
		number=cnt-(currentPage-1)*pageSize; //출력용 글번호
		if(cnt>0) {
			ArrayList<HostVO> dtos=dao.getBookList();
			req.setAttribute("dtos", dtos);
			ArrayList<HostVO> bookin=dao.getBookkindList("국내도서");
			req.setAttribute("bookin",bookin);
			ArrayList<HostVO> bookbest=dao.getBookkindList("베스트셀러");
			req.setAttribute("bookbest",bookbest);
			ArrayList<HostVO> bookout=dao.getBookkindList("해외도서");
			req.setAttribute("bookout",bookout);
			ArrayList<HostVO> booknew=dao.getBookkindList("신간도서");
			req.setAttribute("booknew",booknew);
		}
		startPage=(currentPage/pageBlock)*pageBlock+1;
		if(currentPage % pageBlock ==0) startPage-=pageBlock;
		endPage=startPage+pageBlock-1;
		if(endPage> pageCount)endPage=pageCount;
		req.setAttribute("cnt", cnt);	//글갯수
		req.setAttribute("number", number);	//출력용 글번호
		req.setAttribute("pageNum", pageNum); //페이지 번호
		if(cnt>0) {
			req.setAttribute("startPage", startPage);	//시작페이지
			req.setAttribute("endPage", endPage);	//마지막 페이지
			req.setAttribute("pageBlock", pageBlock);	//출력할 페이지 갯수
			req.setAttribute("pageCount", pageCount);	//페이지 갯수
			req.setAttribute("currentPage", currentPage);	//현재 페이지
		}
		return "/jsp/guest/loginok_Main.jsp";
	}
	public void searchimg(HttpServletRequest req, HttpServletResponse res) {
		String bookimg=req.getParameter("bookimg");
		int pageSize=8; //한 페이지당 출력할 글 갯수
		int pageBlock=3; //한 블럭당 페이지 갯수
		int cnt=0; //글 갯수
		int start=0; //현재 페이지 시작 글번호
		int end=0; //현재 페이지 마지막 글번호
		int number=0; //출력용 글번호
		String pageNum=null; //페이지 번호
		int currentPage=0; //현재페이지
		int pageCount=0; //페이지 갯수
		int startPage=0; //시작페이지
		int endPage=0; //마지막페이지
		HostDAO dao=HostDAOImpl.getInstance();
		cnt=dao.getSearchImgCnt(bookimg);
		pageNum=req.getParameter("pageNum");
		if(pageNum==null) {
			pageNum="1";
		}
		currentPage=Integer.parseInt(pageNum);
		pageCount=(cnt/ pageSize) + (cnt% pageSize >0?1:0);
		start=(currentPage-1)* pageSize+1;
		end=start+pageSize-1;
		if(end>cnt)end=cnt;
		number=cnt-(currentPage-1)*pageSize; //출력용 글번호
		if(cnt>0) {
			ArrayList<HostVO> dtos=dao.searchImg(start,end,bookimg);
			req.setAttribute("dtos", dtos);
			req.setAttribute("booknum", dtos.get(0).getBooknum());
		}
		startPage=(currentPage/pageBlock)*pageBlock+1;
		if(currentPage % pageBlock ==0) startPage-=pageBlock;
		endPage=startPage+pageBlock-1;
		if(endPage> pageCount)endPage=pageCount;
		req.setAttribute("cnt", cnt);	//글갯수
		req.setAttribute("number", number);	//출력용 글번호
		req.setAttribute("pageNum", pageNum); //페이지 번호
		if(cnt>0) {
			req.setAttribute("startPage", startPage);	//시작페이지
			req.setAttribute("endPage", endPage);	//마지막 페이지
			req.setAttribute("pageBlock", pageBlock);	//출력할 페이지 갯수
			req.setAttribute("pageCount", pageCount);	//페이지 갯수
			req.setAttribute("currentPage", currentPage);	//현재 페이지
			req.setAttribute("bookimg", bookimg);
		}
	}

}

	

