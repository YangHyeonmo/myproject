package mvc_service;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import mvc_persistence.GuestDAO;
import mvc_persistence.GuestDAOImpl;
import mvc_persistence.HostDAO;
import mvc_persistence.HostDAOImpl;
import mvc_vo.HostVO;

public class HostServiceImpl implements HostService {

	

	@Override
	public void bookadd(HttpServletRequest req, HttpServletResponse res) {
		MultipartRequest mr=null;
		int maxsize=10*1024*1024;
		String saveDir=req.getRealPath("/images/");
		String realDir="C:\\Users\\Hyeonmo\\Downloads\\java\\eclipse-jee-2018-09-win32-x86_64\\workspace\\Test\\WebContent\\images\\";
		String encType="UTF-8";
		try {
			mr=new MultipartRequest(req,saveDir,maxsize,encType,new DefaultFileRenamePolicy());
			FileInputStream fis= new FileInputStream(saveDir+mr.getFilesystemName("bookimg"));
			FileOutputStream fos=new FileOutputStream(realDir+mr.getFilesystemName("bookimg"));
			int data=0;
			while((data=fis.read())!=-1) {
				fos.write(data);
			}
			fis.close();
			fos.close();		
			String bookimg=mr.getFilesystemName("bookimg");
			String bookkind=mr.getParameter("bookkind");
			String detail=mr.getParameter("detail");
			String bookname=mr.getParameter("bookname");
			String author=mr.getParameter("author");
			int price=Integer.parseInt(mr.getParameter("price"));	
			HostVO vo=new HostVO();
			vo.setBookkind(bookkind);
			vo.setDetail(detail);
			vo.setBookname(bookname);
			vo.setAuthor(author);
			vo.setPrice(price);
			vo.setBookimg(bookimg);
			HostDAO dao=HostDAOImpl.getInstance();
			dao.bookadd(vo);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void bookupdate(HttpServletRequest req, HttpServletResponse res) {
		MultipartRequest mr=null;
		int maxsize=10*1024*1024;
		String saveDir=req.getRealPath("/images/");
		String realDir="C:\\Users\\Hyeonmo\\Downloads\\java\\eclipse-jee-2018-09-win32-x86_64\\workspace\\Test\\WebContent\\images\\";
		String encType="UTF-8";
		try {
			mr=new MultipartRequest(req,saveDir,maxsize,encType,new DefaultFileRenamePolicy());
			FileInputStream fis= new FileInputStream(saveDir+mr.getFilesystemName("bookimg"));
			FileOutputStream fos=new FileOutputStream(realDir+mr.getFilesystemName("bookimg"));
			int data=0;
			while((data=fis.read())!=-1) {
				fos.write(data);
			}
			fis.close();
			fos.close();	
			String bookimg=mr.getFilesystemName("bookimg");
			int booknum=Integer.parseInt(mr.getParameter("booknum"));
			String bookkind=mr.getParameter("bookkind");
			String detail=mr.getParameter("detail");
			String bookname=mr.getParameter("bookname");
			String author=mr.getParameter("author");
			int price=Integer.parseInt(mr.getParameter("price"));
			int bookcount=Integer.parseInt(mr.getParameter("bookcount"));
			HostVO vo=new HostVO();
			vo.setBookimg(bookimg);
			System.out.println(vo.getBookimg());
			vo.setBooknum(booknum);
			vo.setBookkind(bookkind);
			vo.setDetail(detail);
			vo.setBookname(bookname);
			vo.setAuthor(author);
			vo.setPrice(price);
			vo.setBookcount(bookcount);
			HostDAO dao=HostDAOImpl.getInstance();
			dao.bookupdate(vo);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void bookdelete(HttpServletRequest req, HttpServletResponse res) {
		String[] booknum=req.getParameterValues("check");
		HostVO vo=new HostVO();
		HostDAO dao=HostDAOImpl.getInstance();
		for(int i=0;i<booknum.length;i++) {
			vo.setBooknum(Integer.parseInt(booknum[i]));
			dao.bookdelete(vo);
		}
	}

	public void memberdelete(HttpServletRequest req, HttpServletResponse res) {
		String[] membernum=req.getParameterValues("check");
		HostVO vo=new HostVO();
		HostDAO dao=HostDAOImpl.getInstance();
		for(int i=0;i<membernum.length;i++) {
			vo.setMembernum(Integer.parseInt(membernum[i]));
			dao.memberdelete(vo);
		}
		
	}

	@Override
	public void bookList(HttpServletRequest req, HttpServletResponse res) {
		// TODO Auto-generated method stub
				int pageSize=10; //한 페이지당 출력할 글 갯수
				int pageBlock=3; //한 블럭당 페이지 갯수
				int cnt=0; //글 갯수
				int start=0; //현재 페이지 시작 글번호
				int end=0; //현재 페이지 마지막 글번호
				int number=0; //출력용 글번호
				String pageNum=null; //페이지 번호
				int currentPage=0; //현재페이지
				int pageCount=0; //페이지 갯수
				int startPage=0; //시작페이지
				int endPage=0; //마지막페이지
				HostDAO dao=HostDAOImpl.getInstance();
				cnt=dao.getBookCnt();
				pageNum=req.getParameter("pageNum");
				if(pageNum==null) {
					pageNum="1";
				}
				currentPage=Integer.parseInt(pageNum);
				pageCount=(cnt/ pageSize) + (cnt% pageSize >0?1:0);
				start=(currentPage-1)* pageSize+1;
				end=start+pageSize-1;
				if(end>cnt)end=cnt;
				number=cnt-(currentPage-1)*pageSize; //출력용 글번호
				if(cnt>0) {
					ArrayList<HostVO> dtos=dao.getBookList(start, end);
					req.setAttribute("dtos", dtos);
				}
				startPage=(currentPage/pageBlock)*pageBlock+1;
				if(currentPage % pageBlock ==0) startPage-=pageBlock;
				endPage=startPage+pageBlock-1;
				if(endPage> pageCount)endPage=pageCount;
				req.setAttribute("cnt", cnt);	//글갯수
				req.setAttribute("number", number);	//출력용 글번호
				req.setAttribute("pageNum", pageNum); //페이지 번호
				if(cnt>0) {
					req.setAttribute("startPage", startPage);	//시작페이지
					req.setAttribute("endPage", endPage);	//마지막 페이지
					req.setAttribute("pageBlock", pageBlock);	//출력할 페이지 갯수
					req.setAttribute("pageCount", pageCount);	//페이지 갯수
					req.setAttribute("currentPage", currentPage);	//현재 페이지
				}		
	}
	@Override
	public void memberList(HttpServletRequest req, HttpServletResponse res) {
		// TODO Auto-generated method stub
				int pageSize=10; //한 페이지당 출력할 글 갯수
				int pageBlock=3; //한 블럭당 페이지 갯수
				int cnt=0; //글 갯수
				int start=0; //현재 페이지 시작 글번호
				int end=0; //현재 페이지 마지막 글번호
				int number=0; //출력용 글번호
				String pageNum=null; //페이지 번호
				int currentPage=0; //현재페이지
				int pageCount=0; //페이지 갯수
				int startPage=0; //시작페이지
				int endPage=0; //마지막페이지
				HostDAO dao=HostDAOImpl.getInstance();
				cnt=dao.getMemberCnt();
				pageNum=req.getParameter("pageNum");
				if(pageNum==null) {
					pageNum="1";
				}
				currentPage=Integer.parseInt(pageNum);
				pageCount=(cnt/ pageSize) + (cnt% pageSize >0?1:0);
				start=(currentPage-1)* pageSize+1;
				end=start+pageSize-1;
				if(end>cnt)end=cnt;
				number=cnt-(currentPage-1)*pageSize; //출력용 글번호
				if(cnt>0) {
					ArrayList<HostVO> dtos=dao.getMemberList(start, end);
					req.setAttribute("dtos", dtos);
				}
				startPage=(currentPage/pageBlock)*pageBlock+1;
				if(currentPage % pageBlock ==0) startPage-=pageBlock;
				endPage=startPage+pageBlock-1;
				if(endPage> pageCount)endPage=pageCount;
				req.setAttribute("cnt", cnt);	//글갯수
				req.setAttribute("number", number);	//출력용 글번호
				req.setAttribute("pageNum", pageNum); //페이지 번호
				if(cnt>0) {
					req.setAttribute("startPage", startPage);	//시작페이지
					req.setAttribute("endPage", endPage);	//마지막 페이지
					req.setAttribute("pageBlock", pageBlock);	//출력할 페이지 갯수
					req.setAttribute("pageCount", pageCount);	//페이지 갯수
					req.setAttribute("currentPage", currentPage);	//현재 페이지
				}
					
	}
	@Override
	public void orderList(HttpServletRequest req, HttpServletResponse res) {
		int pageSize=10; //한 페이지당 출력할 글 갯수
		int pageBlock=3; //한 블럭당 페이지 갯수
		int cnt=0; //글 갯수
		int start=0; //현재 페이지 시작 글번호
		int end=0; //현재 페이지 마지막 글번호
		int number=0; //출력용 글번호
		String pageNum=null; //페이지 번호
		int currentPage=0; //현재페이지
		int pageCount=0; //페이지 갯수
		int startPage=0; //시작페이지
		int endPage=0; //마지막페이지
		HostDAO dao=HostDAOImpl.getInstance();
		cnt=dao.getOrderCnt("Admin");
		pageNum=req.getParameter("pageNum");
		if(pageNum==null) {
			pageNum="1";
		}
		currentPage=Integer.parseInt(pageNum);
		pageCount=(cnt/ pageSize) + (cnt% pageSize >0?1:0);
		start=(currentPage-1)* pageSize+1;
		end=start+pageSize-1;
		if(end>cnt)end=cnt;
		number=cnt-(currentPage-1)*pageSize; //출력용 글번호
		if(cnt>0) {
			ArrayList<HostVO> dtos=dao.getOrderList(start, end);
			req.setAttribute("dtos", dtos);
		}
		startPage=(currentPage/pageBlock)*pageBlock+1;
		if(currentPage % pageBlock ==0) startPage-=pageBlock;
		endPage=startPage+pageBlock-1;
		if(endPage> pageCount)endPage=pageCount;
		req.setAttribute("cnt", cnt);	//글갯수
		req.setAttribute("number", number);	//출력용 글번호
		req.setAttribute("pageNum", pageNum); //페이지 번호
		if(cnt>0) {
			req.setAttribute("startPage", startPage);	//시작페이지
			req.setAttribute("endPage", endPage);	//마지막 페이지
			req.setAttribute("pageBlock", pageBlock);	//출력할 페이지 갯수
			req.setAttribute("pageCount", pageCount);	//페이지 갯수
			req.setAttribute("currentPage", currentPage);	//현재 페이지
		}			
	}

	@Override
	public void confirm(HttpServletRequest req, HttpServletResponse res) {
		String[] ordernum=req.getParameterValues("check");
		String[] bookcount=req.getParameterValues("bookcount");
		HostVO vo=new HostVO();
		HostDAO dao=HostDAOImpl.getInstance();
		String orderstate="결제승인";
		String name="host";
		for(int i=0;i<ordernum.length;i++) {
			vo=dao.orderfind(Integer.parseInt(ordernum[i]));
			vo.setOrderstate(orderstate);
			HostVO book=dao.bookdb(vo.getBooknum());
			dao.setbcount(book, Integer.parseInt(bookcount[i]),name);
			dao.changeorder(orderstate,Integer.parseInt(ordernum[i]));
		}
	}

	@Override
	public void cancel(HttpServletRequest req, HttpServletResponse res) {
		String[] orderrnum=req.getParameterValues("check");
		String[] bookcount=req.getParameterValues("bookcount");
		HostVO vo=new HostVO();
		HostDAO dao=HostDAOImpl.getInstance();
		String orderstate="결제취소";
		String name="host";
		for(int i=0;i<orderrnum.length;i++) {
			vo=dao.orderfind(Integer.parseInt(orderrnum[i]));
			vo.setOrderstate(orderstate);
			HostVO book=dao.bookdb(vo.getBooknum());
			dao.setbcount(book, Integer.parseInt(bookcount[i]),name);
			dao.changeorder(orderstate,Integer.parseInt(orderrnum[i]));
		}
	}
	@Override
	public void confirmlist(HttpServletRequest req, HttpServletResponse res) {
		int pageSize=10; //한 페이지당 출력할 글 갯수
		int pageBlock=3; //한 블럭당 페이지 갯수
		int cnt=0; //글 갯수
		int start=0; //현재 페이지 시작 글번호
		int end=0; //현재 페이지 마지막 글번호
		int number=0; //출력용 글번호
		String pageNum=null; //페이지 번호
		int currentPage=0; //현재페이지
		int pageCount=0; //페이지 갯수
		int startPage=0; //시작페이지
		int endPage=0; //마지막페이지
		int sum=0;
		String state="결제요청";
		HostDAO dao=HostDAOImpl.getInstance();
		cnt=dao.getStateCnt(state);
		pageNum=req.getParameter("pageNum");
		if(pageNum==null) {
			pageNum="1";
		}
		currentPage=Integer.parseInt(pageNum);
		pageCount=(cnt/ pageSize) + (cnt% pageSize >0?1:0);
		start=(currentPage-1)* pageSize+1;
		end=start+pageSize-1;
		if(end>cnt)end=cnt;
		number=cnt-(currentPage-1)*pageSize; //출력용 글번호
		if(cnt>0) {
			ArrayList<HostVO> dtos=dao.getStateList(start, end,state);
			sum=dao.getTotal(start, end, state);
			req.setAttribute("dtos", dtos);
		}
		startPage=(currentPage/pageBlock)*pageBlock+1;
		if(currentPage % pageBlock ==0) startPage-=pageBlock;
		endPage=startPage+pageBlock-1;
		if(endPage> pageCount)endPage=pageCount;
		req.setAttribute("cnt", cnt);	//글갯수
		req.setAttribute("number", number);	//출력용 글번호
		req.setAttribute("pageNum", pageNum); //페이지 번호
		if(cnt>0) {
			req.setAttribute("startPage", startPage);	//시작페이지
			req.setAttribute("endPage", endPage);	//마지막 페이지
			req.setAttribute("pageBlock", pageBlock);	//출력할 페이지 갯수
			req.setAttribute("pageCount", pageCount);	//페이지 갯수
			req.setAttribute("currentPage", currentPage);	//현재 페이지
			req.setAttribute("sum", sum);
		}			
	}
	@Override
	public void cancellist(HttpServletRequest req, HttpServletResponse res) {
		int pageSize=10; //한 페이지당 출력할 글 갯수
		int pageBlock=3; //한 블럭당 페이지 갯수
		int cnt=0; //글 갯수
		int start=0; //현재 페이지 시작 글번호
		int end=0; //현재 페이지 마지막 글번호
		int number=0; //출력용 글번호
		String pageNum=null; //페이지 번호
		int currentPage=0; //현재페이지
		int pageCount=0; //페이지 갯수
		int startPage=0; //시작페이지
		int endPage=0; //마지막페이지
		String state="환불요청";
		HostDAO dao=HostDAOImpl.getInstance();
		cnt=dao.getStateCnt(state);
		pageNum=req.getParameter("pageNum");
		if(pageNum==null) {
			pageNum="1";
		}
		currentPage=Integer.parseInt(pageNum);
		pageCount=(cnt/ pageSize) + (cnt% pageSize >0?1:0);
		start=(currentPage-1)* pageSize+1;
		end=start+pageSize-1;
		if(end>cnt)end=cnt;
		number=cnt-(currentPage-1)*pageSize; //출력용 글번호
		if(cnt>0) {
			ArrayList<HostVO> dtos=dao.getStateList(start, end,state);
			req.setAttribute("dtos", dtos);
		}
		startPage=(currentPage/pageBlock)*pageBlock+1;
		if(currentPage % pageBlock ==0) startPage-=pageBlock;
		endPage=startPage+pageBlock-1;
		if(endPage> pageCount)endPage=pageCount;
		req.setAttribute("cnt", cnt);	//글갯수
		req.setAttribute("number", number);	//출력용 글번호
		req.setAttribute("pageNum", pageNum); //페이지 번호
		if(cnt>0) {
			req.setAttribute("startPage", startPage);	//시작페이지
			req.setAttribute("endPage", endPage);	//마지막 페이지
			req.setAttribute("pageBlock", pageBlock);	//출력할 페이지 갯수
			req.setAttribute("pageCount", pageCount);	//페이지 갯수
			req.setAttribute("currentPage", currentPage);	//현재 페이지
		}			
	}
	@Override
	public void resultlist(HttpServletRequest req, HttpServletResponse res) {
		int pageSize=10; //한 페이지당 출력할 글 갯수
		int pageBlock=3; //한 블럭당 페이지 갯수
		int cnt=0; //글 갯수
		int start=0; //현재 페이지 시작 글번호
		int end=0; //현재 페이지 마지막 글번호
		int number=0; //출력용 글번호
		String pageNum=null; //페이지 번호
		int currentPage=0; //현재페이지
		int pageCount=0; //페이지 갯수
		int startPage=0; //시작페이지
		int endPage=0; //마지막페이지
		String state="결제승인";
		int sum=0;
		HostDAO dao=HostDAOImpl.getInstance();
		cnt=dao.getStateCnt(state);
		pageNum=req.getParameter("pageNum");
		if(pageNum==null) {
			pageNum="1";
		}
		currentPage=Integer.parseInt(pageNum);
		pageCount=(cnt/ pageSize) + (cnt% pageSize >0?1:0);
		start=(currentPage-1)* pageSize+1;
		end=start+pageSize-1;
		if(end>cnt)end=cnt;
		number=cnt-(currentPage-1)*pageSize; //출력용 글번호
		if(cnt>0) {
			ArrayList<HostVO> dtos=dao.getStateList(start, end,state);
			sum=dao.getTotal(start, end, state);
			req.setAttribute("dtos", dtos);
		}
		startPage=(currentPage/pageBlock)*pageBlock+1;
		if(currentPage % pageBlock ==0) startPage-=pageBlock;
		endPage=startPage+pageBlock-1;
		if(endPage> pageCount)endPage=pageCount;
			req.setAttribute("cnt", cnt);	//글갯수
			req.setAttribute("number", number);	//출력용 글번호
			req.setAttribute("pageNum", pageNum); //페이지 번호
		if(cnt>0) {
			req.setAttribute("startPage", startPage);	//시작페이지
			req.setAttribute("endPage", endPage);	//마지막 페이지
			req.setAttribute("pageBlock", pageBlock);	//출력할 페이지 갯수
			req.setAttribute("pageCount", pageCount);	//페이지 갯수
			req.setAttribute("currentPage", currentPage);	//현재 페이지
			req.setAttribute("sum", sum);
		}			
	}
	@Override
	public void Chart(HttpServletRequest req, HttpServletResponse res) {
		HostDAO dao=HostDAOImpl.getInstance();
		String Monthstart=(req.getParameter("startDate")==null)?"20170101 ":req.getParameter("startDate");
		String Monthend=(req.getParameter("endDate")==null)?"20181201 ":req.getParameter("endDate");
		int onlymonth=(req.getParameter("endDate")==null)? 0:Integer.parseInt(Monthstart.substring(5,7));
		Monthstart = Monthstart.replace('.', ' ');
		Monthstart=Monthstart.replace(" ", "");
		Monthend = Monthend.replace('.', ' ');
		Monthend=Monthend.replace(" ", "");
		Monthstart=Monthstart.substring(0,6);
		Monthend=Monthend.substring(0,6);
		String startyear=Monthstart.substring(0,4);
		int bookin=dao.resultbk("국내도서");
		int bookout=dao.resultbk("해외도서");
		int booknew=dao.resultbk("신간도서");
		int bookbest=dao.resultbk("베스트셀러");
		int novel=dao.resultdt("소설");
		int selfnew=dao.resultdt("화제의 신간");
		int best=dao.resultdt("베스트셀러");
		ArrayList<Integer> result=dao.monthSum(Monthstart,Monthend);
		req.setAttribute("novel", novel);
		req.setAttribute("selfnew", selfnew);
		req.setAttribute("best", best);
		req.setAttribute("bookin", bookin);
		req.setAttribute("bookout", bookout);
		req.setAttribute("booknew", booknew);
		req.setAttribute("bookbest", bookbest);
		req.setAttribute("startyear", startyear);
		req.setAttribute("onlymonth", onlymonth);
		req.setAttribute("result", result);
	}	
	@Override
	public void priceChart(HttpServletRequest req, HttpServletResponse res) {
		int min=Integer.parseInt(req.getParameter("minprice"));
		int max=Integer.parseInt(req.getParameter("maxprice"));
		HostDAO dao=HostDAOImpl.getInstance();
		int price=dao.resultprice(min,max);
		req.setAttribute("price", price);
		req.setAttribute("min", min);
		req.setAttribute("max", max);
	}

	public void boarddelete(HttpServletRequest req, HttpServletResponse res) {
		String[] boardnum=req.getParameterValues("check");
		GuestDAO dao=GuestDAOImpl.getInstance();
		for(int i=0;i<boardnum.length;i++) {
			dao.deleteBoard(Integer.parseInt(boardnum[i]));
		}
	}

	public void dealdelete(HttpServletRequest req, HttpServletResponse res) {
		String[] dealnum=req.getParameterValues("check");
		HostDAO dao=HostDAOImpl.getInstance();
		for(int i=0;i<dealnum.length;i++) {
			dao.deleteDeal(Integer.parseInt(dealnum[i]));
		}
	}

	public void commentdelete(HttpServletRequest req, HttpServletResponse res) {
		String[] commentnum=req.getParameterValues("check");
		HostDAO dao=HostDAOImpl.getInstance();
		for(int i=0;i<commentnum.length;i++) {
			dao.deleteComment(Integer.parseInt(commentnum[i]));
		}
	}


}
