package mvc_persistence;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc_vo.GuestVO;
import mvc_vo.HostVO;
public interface GuestDAO {
	public int insertGuest(GuestVO vo);
	public int idCheck(String id);
	public int idPwdCheck(String id,String pwd);
	public GuestVO getMemberinfo(String id);
	public int updateMember(GuestVO vo);
	public int deleteMember(String id,String pwd);
	public int infoMember(String id);
	public ArrayList<GuestVO> getBoardList(int start,int end,String admin);
	public GuestVO getArticle(int num);
	public int addReadCnt(int num);
	public int insertBoard(GuestVO vo);
	public int numPwdCheck(int num, String pwd);
	public GuestVO getBoard(int boardnum);
	public int updateBoard(String subject, String content, int boardnum);
	public int deleteBoard(int boardnum);
	public int insertDeal(GuestVO vo);
	public int getDealCnt();
	public ArrayList<GuestVO> getDealList(int start, int end);
	public int addDealCnt(int dealnum);
	public GuestVO getDeal(int dealnum);
	public int insertrequest(GuestVO vo);
	public int getNoteCnt();
	public ArrayList<GuestVO> getNoteList(int start, int end, String id);
	public GuestVO getNote(int requestnum);
	public void deleterequest(GuestVO vo);
	public void changedeal(GuestVO vo);
	public int insertcomment(GuestVO vo);
	public int getCommentCnt(int boardnum);
	public ArrayList<GuestVO> getCommentList(int start, int end, int boardnum);
	public String matchid(String findemail, String findphone);
	public String matchpwd(String findid, String findemail, String findphone);
	public ArrayList<GuestVO> boardsearch(int start,int end,String board,String boardselect);
	public int getBoardCnt() ;
	public ArrayList<GuestVO> dealsearch(int start, int end, String deal, String dealselect);
	public ArrayList<GuestVO> getAdminList(int start, int end, String admin);
	public GuestVO getAddress(String userid);
	public int getPageCnt(String board,String boardselect,String admin);
	
}
