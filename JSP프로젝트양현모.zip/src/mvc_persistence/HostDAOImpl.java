package mvc_persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import mvc_vo.HostVO;

public class HostDAOImpl implements HostDAO{
	private static HostDAOImpl hd=new HostDAOImpl();
	public static HostDAOImpl getInstance() {
		return hd;
	}
	DataSource datasource;
	
	private HostDAOImpl() {
		try {
			Context context=new InitialContext();
			datasource=(DataSource)context.lookup("java:comp/env/jdbc/Oracle11gHyeonmo");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	@Override
	public int idPwdCheck(String id, String pwd) {
		int logincnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="select * from  host where hostid=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				if(pwd.equals(rs.getString("password"))){
					logincnt=1;
				}else {
					logincnt=-1;
				}
			}else {
				logincnt=0;
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return logincnt;
	}
	

	@Override
	public void bookadd(HostVO vo) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=datasource.getConnection();
			String sql="INSERT INTO book values(b_incre.NEXTVAL,?,?,?,?,?,?,100)";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1,vo.getBookkind());
			pstmt.setString(2,vo.getDetail());
			pstmt.setString(3,vo.getBookname());
			pstmt.setString(4,vo.getAuthor());
			pstmt.setInt(5,vo.getPrice());
			pstmt.setString(6, vo.getBookimg());
			int s=pstmt.executeUpdate();	
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			if(pstmt!=null)try{pstmt.close();}catch(SQLException ex){}						
			if(conn!=null)try{conn.close();}catch(SQLException ex){}
		}
	}
	@Override
	public void bookupdate(HostVO vo) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=datasource.getConnection();
			String sql="update book set bookkind=?,detail=?,bookname=?,author=?,price=?,bookimg=?,b_count=? where booknum=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1,vo.getBookkind());
			pstmt.setString(2,vo.getDetail());
			pstmt.setString(3,vo.getBookname());
			pstmt.setString(4,vo.getAuthor());
			pstmt.setInt(5,vo.getPrice());
			pstmt.setString(6, vo.getBookimg());
			pstmt.setInt(7, vo.getBookcount());
			pstmt.setInt(8, vo.getBooknum());
			int s=pstmt.executeUpdate();	
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			if(pstmt!=null)try{pstmt.close();}catch(SQLException ex){}						
			if(conn!=null)try{conn.close();}catch(SQLException ex){}
		}
	}
	@Override
	public void bookdelete(HostVO vo) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=datasource.getConnection();
			String sql="delete from book where booknum=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, vo.getBooknum());
			int s=pstmt.executeUpdate();	
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			if(pstmt!=null)try{pstmt.close();}catch(SQLException ex){}						
			if(conn!=null)try{conn.close();}catch(SQLException ex){}
		}
	}
	@Override
	public void memberdelete(HostVO vo) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=datasource.getConnection();
			String sql="delete from member where membernum=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, vo.getMembernum());
			int s=pstmt.executeUpdate();	
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			if(pstmt!=null)try{pstmt.close();}catch(SQLException ex){}						
			if(conn!=null)try{conn.close();}catch(SQLException ex){}
		}
		
	}
	@Override
	public ArrayList<HostVO> getBookList(int start,int end) {
		ArrayList<HostVO> dtos=null;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="SELECT * " + 
					"FROM (SELECT booknum,bookkind,detail,bookname,author,price,bookimg,b_count,rownum rNum " + 
							"FROM("+ 
					            "select * from book " + 					            
					            ")" + 	
					        ")" + 
					"where rNum>=? AND rNum<=? order by booknum desc";	//넘겨받은 start값 end값을 rNum으로 조회
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, start);
			pstmt.setInt(2, end);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				dtos=new ArrayList<HostVO>(rs.getRow()+1);
				do {
					HostVO vo=new HostVO();
					vo.setBooknum(rs.getInt("booknum"));
					vo.setBookkind(rs.getString("bookkind"));
					vo.setDetail(rs.getString("detail"));
					vo.setBookname(rs.getString("bookname"));
					vo.setAuthor(rs.getString("author"));
					vo.setPrice(rs.getInt("price"));
					vo.setBookimg(rs.getString("bookimg"));
					vo.setBookcount(rs.getInt("b_count"));
					dtos.add(vo);
			
				}while(rs.next());
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return dtos;
	}
	@Override
	public ArrayList<HostVO> getBookList() {
		ArrayList<HostVO> dtos=null;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="SELECT * " + 
					"FROM (SELECT booknum,bookkind,detail,bookname,author,price,bookimg,b_count,rownum rNum " + 
							"FROM("+ 
					            "select * from book " + 					            
					            ")" + 	
					        ")" + 
					" order by booknum desc";	//넘겨받은 start값 end값을 rNum으로 조회
			pstmt=conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				dtos=new ArrayList<HostVO>(rs.getRow()+1);
				do {
					HostVO vo=new HostVO();
					vo.setBooknum(rs.getInt("booknum"));
					vo.setBookkind(rs.getString("bookkind"));
					vo.setDetail(rs.getString("detail"));
					vo.setBookname(rs.getString("bookname"));
					vo.setAuthor(rs.getString("author"));
					vo.setPrice(rs.getInt("price"));
					vo.setBookimg(rs.getString("bookimg"));
					vo.setBookcount(rs.getInt("b_count"));
					dtos.add(vo);
			
				}while(rs.next());
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return dtos;
	}
	
	@Override
	public ArrayList<HostVO> getMemberList(int start, int end) {
		ArrayList<HostVO> dtos=null;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="SELECT * " + 
					"FROM (SELECT membernum,id,password,phone,email,postnum,address,name,jumin,rownum rNum " + 
							"FROM("+ 
					            "select * from member " + 					            
					            ")" + 	
					        ")" + 
					"WHERE rNum >=? AND rNum<=? order by membernum desc";	//넘겨받은 start값 end값을 rNum으로 조회
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, start);
			pstmt.setInt(2, end);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				dtos=new ArrayList<HostVO>(end-start+1);
				do {
					HostVO vo=new HostVO();
					vo.setMembernum(rs.getInt("membernum"));
					vo.setId(rs.getString("id"));
					vo.setPassword(rs.getString("password"));
					vo.setPhone(rs.getString("phone"));
					vo.setEmail(rs.getString("email"));
					vo.setPostnum(rs.getString("postnum"));
					vo.setAddress(rs.getString("address"));
					vo.setName(rs.getString("name"));
					vo.setJumin(rs.getString("jumin"));
					dtos.add(vo);
				}while(rs.next());
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return dtos;
	}
	@Override
	public int getBookCnt() {
		int bookcnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
		conn=datasource.getConnection();
		String sql="select count(*) from book";
		pstmt=conn.prepareStatement(sql);
		rs=pstmt.executeQuery();
			if(rs.next()) {
				bookcnt=rs.getInt(1);	//컬럼의 인덱스
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return bookcnt;
	}
	@Override
	public int getMemberCnt() {
		int membercnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
		conn=datasource.getConnection();
		String sql="select count(*) from member";
		pstmt=conn.prepareStatement(sql);
		rs=pstmt.executeQuery();
			if(rs.next()) {
				membercnt=rs.getInt(1);	//컬럼의 인덱스
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return membercnt;
	}
	@Override
	public ArrayList<HostVO> booksearch(int start,int end,String bookname,String bookselect) {
		ArrayList<HostVO> dtos=null;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="select booknum,Bookname,Bookkind,Detail,author,Price,bookimg from book where "+bookselect+"  Like ? order by booknum";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1,bookname+"%");
			rs=pstmt.executeQuery();
			if(rs.next()) {
				dtos=new ArrayList<HostVO>(end-start+1);
				do {
					HostVO vo=new HostVO();
					vo.setBooknum(rs.getInt("booknum"));
					vo.setBookname(rs.getString("bookname"));
					vo.setBookkind(rs.getString("bookkind"));
					vo.setDetail(rs.getString("detail"));
					vo.setAuthor(rs.getString("author"));
					vo.setPrice(rs.getInt("price"));
					vo.setBookimg(rs.getString("bookimg"));
					dtos.add(vo);
				}while(rs.next());
			}
			}catch(SQLException e){
				e.printStackTrace();
			}finally {
				try {
					if(rs!=null) rs.close();
					if(pstmt!=null)pstmt.close();
					if(conn!=null)conn.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		return dtos;
	}
	@Override
	public ArrayList<HostVO> booksearch(int start,int end,int booknum) {
		ArrayList<HostVO> dtos=null;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="select booknum,Bookname,Bookkind,Detail,author,Price,bookimg from book where booknum=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1,booknum);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				dtos=new ArrayList<HostVO>(end-start+1);
				do {
					HostVO vo=new HostVO();
					vo.setBooknum(rs.getInt("booknum"));
					vo.setBookname(rs.getString("bookname"));
					vo.setBookkind(rs.getString("bookkind"));
					vo.setDetail(rs.getString("detail"));
					vo.setAuthor(rs.getString("author"));
					vo.setPrice(rs.getInt("price"));
					vo.setBookimg(rs.getString("bookimg"));
					dtos.add(vo);
				}while(rs.next());
			}
			}catch(SQLException e){
				e.printStackTrace();
			}finally {
				try {
					if(rs!=null) rs.close();
					if(pstmt!=null)pstmt.close();
					if(conn!=null)conn.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		return dtos;
	}
	@Override
	public void inputcart(HostVO vo,String userid) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=datasource.getConnection();
			String sql="INSERT INTO cart values(cart_seq.NEXTVAL,(select membernum from member where id=?),?,?,?,?,?,?,?)";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1,userid);
			pstmt.setInt(2,vo.getBooknum());
			pstmt.setString(3,vo.getBookkind());
			pstmt.setString(4,vo.getDetail());
			pstmt.setString(5,vo.getBookname());
			pstmt.setString(6,vo.getAuthor());
			pstmt.setInt(7,vo.getPrice());
			pstmt.setString(8, vo.getBookimg());
			int s=pstmt.executeUpdate();	
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			if(pstmt!=null)try{pstmt.close();}catch(SQLException ex){}						
			if(conn!=null)try{conn.close();}catch(SQLException ex){}
		}
	}
	@Override
	public int getCartCnt() {
		int cartcnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
		conn=datasource.getConnection();
		String sql="select count(*) from cart";
		pstmt=conn.prepareStatement(sql);
		rs=pstmt.executeQuery();
			if(rs.next()) {
				cartcnt=rs.getInt(1);	//컬럼의 인덱스
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return cartcnt;
	}
	@Override
	public ArrayList<HostVO> getCartList(int start, int end,String id) {
		ArrayList<HostVO> dtos=null;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="SELECT * " + 
					"FROM (SELECT cartnum,membernum,booknum,bookkind,detail,bookname,author,price,bookimg,rownum rNum " + 
							"FROM("+ 
					            "select * from cart " + 					            
					            ")" + 	
					        ")" + 
					"WHERE rNum >=? AND rNum<=? AND membernum=(select membernum from member where id=?)";	//넘겨받은 start값 end값을 rNum으로 조회
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, start);
			pstmt.setInt(2, end);
			pstmt.setString(3, id);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				dtos=new ArrayList<HostVO>(end-start+1);
				do {
					HostVO vo=new HostVO();
					vo.setCartnum(rs.getInt("cartnum"));
					vo.setBooknum(rs.getInt("booknum"));
					vo.setBookkind(rs.getString("bookkind"));
					vo.setDetail(rs.getString("detail"));
					vo.setBookname(rs.getString("bookname"));
					vo.setAuthor(rs.getString("author"));
					vo.setPrice(rs.getInt("price"));
					vo.setBookimg(rs.getString("bookimg"));
					dtos.add(vo);
				}while(rs.next());
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return dtos;
	}
	@Override
	public void inputOrder(HostVO vo,String userid) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=datasource.getConnection();
			String sql="INSERT INTO bookorder values(order_seq.NEXTVAL,?,(select membernum from member where id=?),?,?,?,?,?,?,?,?,?,?,?,?,sysdate)";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1,vo.getCartnum());
			pstmt.setString(2,userid);
			pstmt.setInt(3,vo.getBooknum());
			pstmt.setString(4,vo.getBookkind());
			pstmt.setString(5,vo.getDetail());
			pstmt.setString(6,vo.getBookname());
			pstmt.setString(7,vo.getAuthor());
			pstmt.setInt(8,vo.getPrice());
			pstmt.setInt(9, vo.getBookcount());
			pstmt.setString(10, vo.getOrderstate());
			pstmt.setString(11, vo.getBookimg());
			pstmt.setString(12, vo.getReceiver());
			pstmt.setString(13, vo.getRe_phone());
			pstmt.setString(14, vo.getRe_post());
			int s=pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			if(pstmt!=null)try{pstmt.close();}catch(SQLException ex){}						
			if(conn!=null)try{conn.close();}catch(SQLException ex){}
		}
	}
	@Override
	public int getOrderCnt(String id) {
		int ordercnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
		conn=datasource.getConnection();
		String sql="";
		if(id.equals("Admin")) {
			sql="select count(*) from bookorder";
			pstmt=conn.prepareStatement(sql);
		}else {
			sql="select count(*) from bookorder where membernum=(select membernum from member where id=?) ";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, id);
		}
		rs=pstmt.executeQuery();
			if(rs.next()) {
				ordercnt=rs.getInt(1);	//컬럼의 인덱스
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return ordercnt;
	}
	public ArrayList<HostVO> getOrderList(String id) {
		ArrayList<HostVO> dtos=null;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="SELECT * " + 
					"FROM (SELECT ordernum,membernum,booknum,bookkind,detail,bookname,author,price,b_count,orderstate,bookimg " + 
							"FROM("+ 
					            "select * from bookorder " + 					            
					            ")" + 	
					        ")" + 
					"WHERE membernum= (select membernum from member where id=?) ";	//넘겨받은 start값 end값을 rNum으로 조회
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				dtos=new ArrayList<HostVO>(rs.getRow()+1);
				do {
					HostVO vo=new HostVO();
					vo.setOrdernum(rs.getInt("ordernum"));
					vo.setBooknum(rs.getInt("booknum"));
					vo.setBookkind(rs.getString("bookkind"));
					vo.setDetail(rs.getString("detail"));
					vo.setBookname(rs.getString("bookname"));
					vo.setAuthor(rs.getString("author"));
					vo.setPrice(rs.getInt("price"));
					vo.setBookcount(rs.getInt("b_count"));
					vo.setOrderstate(rs.getString("orderstate"));
					vo.setBookimg(rs.getString("bookimg"));
					dtos.add(vo);
				}while(rs.next());
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return dtos;
	}

	@Override
	public ArrayList<HostVO> getOrderList(int start, int end) {
		ArrayList<HostVO> dtos=null;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="SELECT * " + 
					"FROM (SELECT ordernum,membernum,booknum,bookkind,detail,bookname,author,price,b_count,orderstate,bookimg,rownum rNum " + 
							"FROM("+ 
					            "select * from bookorder " + 					            
					            ")" + 	
					        ")" + 
					"WHERE rNum >=? AND rNum<=? order by ordernum desc";	//넘겨받은 start값 end값을 rNum으로 조회
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, start);
			pstmt.setInt(2, end);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				dtos=new ArrayList<HostVO>(end-start+1);
				do {
					HostVO vo=new HostVO();
					vo.setOrdernum(rs.getInt("ordernum"));
					vo.setBooknum(rs.getInt("booknum"));
					vo.setBookkind(rs.getString("bookkind"));
					vo.setDetail(rs.getString("detail"));
					vo.setBookname(rs.getString("bookname"));
					vo.setAuthor(rs.getString("author"));
					vo.setPrice(rs.getInt("price"));
					vo.setBookcount(rs.getInt("b_count"));
					vo.setOrderstate(rs.getString("orderstate"));
					vo.setBookimg(rs.getString("bookimg"));
					dtos.add(vo);
				}while(rs.next());
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return dtos;
	}
	@Override
	public void deletecart(HostVO vo, String userid) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=datasource.getConnection();
			String sql="delete cart where booknum=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1,vo.getBooknum());
			int s=pstmt.executeUpdate();	
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			if(pstmt!=null)try{pstmt.close();}catch(SQLException ex){}						
			if(conn!=null)try{conn.close();}catch(SQLException ex){}
		}
	}
	@Override
	public void changeorder(String orderstate,int cartnum) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=datasource.getConnection();
			String sql="update bookorder set orderstate=? where ordernum=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, orderstate);
			pstmt.setInt(2, cartnum);
			int s=pstmt.executeUpdate();	
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			if(pstmt!=null)try{pstmt.close();}catch(SQLException ex){}						
			if(conn!=null)try{conn.close();}catch(SQLException ex){}
		}
	}
	@Override
	public int getStateCnt(String state) {
		int statecnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
		conn=datasource.getConnection();
		String sql="select count(*) from bookorder where orderstate=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, state);
		rs=pstmt.executeQuery();
			if(rs.next()) {
				statecnt=rs.getInt(1);	//컬럼의 인덱스
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return statecnt;
	}
	@Override
	public int getRefundCnt(String state,String id) {
		int statecnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
		conn=datasource.getConnection();
		String sql="select count(*) from bookorder where orderstate=? AND membernum=(select membernum from member where id=?)";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, state);
		pstmt.setString(2, id);
		rs=pstmt.executeQuery();
			if(rs.next()) {
				statecnt=rs.getInt(1);	//컬럼의 인덱스
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return statecnt;
	}
	@Override
	public ArrayList<HostVO> getStateList(int start, int end,String state) {
		ArrayList<HostVO> dtos=null;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="SELECT * from bookorder where orderstate=? ";	//넘겨받은 start값 end값을 rNum으로 조회
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, state);
			rs=pstmt.executeQuery();
			if(rs.next()) {
			dtos=new ArrayList<HostVO>(end-start+1);
				do{
					HostVO vo=new HostVO();
					vo.setOrdernum(rs.getInt("ordernum"));
					vo.setBooknum(rs.getInt("booknum"));
					vo.setBookkind(rs.getString("bookkind"));
					vo.setDetail(rs.getString("detail"));
					vo.setBookname(rs.getString("bookname"));
					vo.setAuthor(rs.getString("author"));
					vo.setPrice(rs.getInt("price"));
					vo.setBookcount(rs.getInt("b_count"));
					vo.setOrderstate(rs.getString("orderstate"));
					vo.setBookimg(rs.getString("bookimg"));
					dtos.add(vo);
				}while(rs.next());
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return dtos;
	}
	@Override
	public ArrayList<HostVO> getRefundList(int start, int end,String state,String id) {
		ArrayList<HostVO> dtos=null;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="SELECT * from bookorder where orderstate=? AND membernum=(select membernum from member where id=?)";	//넘겨받은 start값 end값을 rNum으로 조회
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, state);
			pstmt.setString(2, id);
			rs=pstmt.executeQuery();
			if(rs.next()) {
			dtos=new ArrayList<HostVO>(end-start+1);
				do{
					HostVO vo=new HostVO();
					vo.setOrdernum(rs.getInt("ordernum"));
					vo.setBooknum(rs.getInt("booknum"));
					vo.setBookkind(rs.getString("bookkind"));
					vo.setDetail(rs.getString("detail"));
					vo.setBookname(rs.getString("bookname"));
					vo.setAuthor(rs.getString("author"));
					vo.setPrice(rs.getInt("price"));
					vo.setBookcount(rs.getInt("b_count"));
					vo.setOrderstate(rs.getString("orderstate"));
					vo.setBookimg(rs.getString("bookimg"));
					dtos.add(vo);
				}while(rs.next());
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return dtos;
	}
	@Override
	public int getTotal(int start,int end,String state) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		int sum=0;
		try {
			conn=datasource.getConnection();
			String sql="SELECT SUM(price*b_count) as result from bookorder where orderstate=?";	//넘겨받은 start값 end값을 rNum으로 조회
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, state);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				HostVO vo=new HostVO();
				 sum=rs.getInt("result");
				 vo.setSum(sum);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return sum;
	}
	@Override
	public int getSearchCnt(String book,String bookselect) {
		int boardcnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
		conn=datasource.getConnection();
		String sql="SELECT COUNT(*) FROM  book WHERE "+bookselect+" Like ? "; 
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, book+"%");
		rs=pstmt.executeQuery();
			if(rs.next()) {
				boardcnt=rs.getInt(1);	//컬럼의 인덱스
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return boardcnt;
	}
	@Override
	public int resultbk(String bookkind) {
		int sum=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="SELECT SUM(price*b_count) as result  from bookorder where bookkind=? AND orderstate='결제승인'";	//넘겨받은 start값 end값을 rNum으로 조회
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, bookkind);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				HostVO vo=new HostVO();
				 sum=rs.getInt("result");
				 vo.setSum(sum);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return sum;
		
	}
	@Override
	public int resultdt(String detail) {
		int sum=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="SELECT SUM(price*b_count) as result from bookorder where detail=? AND orderstate='결제승인'";	//넘겨받은 start값 end값을 rNum으로 조회
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, detail);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				HostVO vo=new HostVO();
				 sum=rs.getInt("result");
				 vo.setSum(sum);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return sum;
		
	}
	@Override
	public int resultprice(int min,int max) {
		int sum=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="SELECT SUM(price*b_count) as result from bookorder where price>=? AND price<? AND orderstate='결제승인'";	//넘겨받은 start값 end값을 rNum으로 조회
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, min);
			pstmt.setInt(2, max);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				HostVO vo=new HostVO();
				 sum=rs.getInt("result");
				 vo.setSum(sum);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return sum;
		
	}
	@Override
	public int setbcount(HostVO vo, int bookcount,String name) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		int cnt=0;
		try {
			conn=datasource.getConnection();
			String sql="update book set b_count=? where booknum=?";
			pstmt=conn.prepareStatement(sql);
			if(vo.getBookcount()-bookcount>0) {
				if(name.equals("guest")) {
					pstmt.setInt(1,vo.getBookcount()-bookcount);
				}else {
					pstmt.setInt(1,vo.getBookcount()+bookcount);
				}
				cnt=1;
			}else {
				pstmt.setInt(1,vo.getBookcount());
				cnt=0;
			}
			pstmt.setInt(2, vo.getBooknum());
			int s=pstmt.executeUpdate();	
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			if(pstmt!=null)try{pstmt.close();}catch(SQLException ex){}						
			if(conn!=null)try{conn.close();}catch(SQLException ex){}
		}
		return cnt;
	}
	@Override
	public HostVO bookdb(int booknum) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		HostVO vo=new HostVO();
		try {
			conn=datasource.getConnection();
			String sql="select * from book where booknum=? ";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, booknum);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				vo.setBooknum(rs.getInt("booknum"));
				vo.setBookkind(rs.getString("bookkind"));
				vo.setDetail(rs.getString("detail"));
				vo.setBookname(rs.getString("bookname"));
				vo.setAuthor(rs.getString("author"));
				vo.setPrice(rs.getInt("price"));
				vo.setBookimg(rs.getString("bookimg"));
				vo.setBookcount(rs.getInt("b_count"));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			if(pstmt!=null)try{pstmt.close();}catch(SQLException ex){}						
			if(conn!=null)try{conn.close();}catch(SQLException ex){}
		}
		return vo;
	}
	@Override
	public HostVO cartfind(int booknum) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		HostVO vo=new HostVO();
		try {
			conn=datasource.getConnection();
			String sql="select * from cart where booknum=? ";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, booknum);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				vo.setCartnum(rs.getInt("cartnum"));
				vo.setBooknum(rs.getInt("booknum"));
				vo.setBookkind(rs.getString("bookkind"));
				vo.setDetail(rs.getString("detail"));
				vo.setBookname(rs.getString("bookname"));
				vo.setAuthor(rs.getString("author"));
				vo.setPrice(rs.getInt("price"));
				vo.setBookimg(rs.getString("bookimg"));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			if(pstmt!=null)try{pstmt.close();}catch(SQLException ex){}						
			if(conn!=null)try{conn.close();}catch(SQLException ex){}
		}
		return vo;
	}
	@Override
	public HostVO orderfind(int booknum) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		HostVO vo=new HostVO();
		try {
			conn=datasource.getConnection();
			String sql="select * from bookorder where booknum=? ";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, booknum);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				vo.setOrdernum(rs.getInt("ordernum"));
				vo.setCartnum(rs.getInt("cartnum"));
				vo.setBooknum(rs.getInt("booknum"));
				vo.setBookkind(rs.getString("bookkind"));
				vo.setDetail(rs.getString("detail"));
				vo.setBookname(rs.getString("bookname"));
				vo.setAuthor(rs.getString("author"));
				vo.setPrice(rs.getInt("price"));
				vo.setBookimg(rs.getString("bookimg"));
				vo.setBookcount(rs.getInt("b_count"));
				vo.setOrderstate(rs.getString("orderstate"));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			if(pstmt!=null)try{pstmt.close();}catch(SQLException ex){}						
			if(conn!=null)try{conn.close();}catch(SQLException ex){}
		}
		return vo;
	}
	@Override
	public HostVO cartdb(int cartnum) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		HostVO vo=new HostVO();
		try {
			conn=datasource.getConnection();
			String sql="select * from cart where cartnum=? ";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, cartnum);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				vo.setCartnum(rs.getInt("cartnum"));
				vo.setBooknum(rs.getInt("booknum"));
				vo.setBookkind(rs.getString("bookkind"));
				vo.setDetail(rs.getString("detail"));
				vo.setBookname(rs.getString("bookname"));
				vo.setAuthor(rs.getString("author"));
				vo.setPrice(rs.getInt("price"));
				vo.setBookimg(rs.getString("bookimg"));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			if(pstmt!=null)try{pstmt.close();}catch(SQLException ex){}						
			if(conn!=null)try{conn.close();}catch(SQLException ex){}
		}
		return vo;
	}
	@Override
	public int setordercount(HostVO vo,int bookcount) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		int s=0;
		try {
			conn=datasource.getConnection();
			String sql="update bookorder set b_count=? where cartnum=? AND orderstate='결제요청'";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1,bookcount);
			pstmt.setInt(2, vo.getCartnum());
			s=pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			if(pstmt!=null)try{pstmt.close();}catch(SQLException ex){}						
			if(conn!=null)try{conn.close();}catch(SQLException ex){}
		}
		return s;
	}
	@Override
	public  ArrayList<HostVO> imageinfo(String bookimg) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		ArrayList<HostVO> dtos=new ArrayList<HostVO>();
		try {
			conn=datasource.getConnection();
			String sql="select * from book where bookimg=? ";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, bookimg);
			rs=pstmt.executeQuery(); 
				while(rs.next()){
					HostVO vo=new HostVO();
					vo.setBooknum(rs.getInt("booknum"));
					vo.setBookkind(rs.getString("bookkind"));
					vo.setDetail(rs.getString("detail"));
					vo.setBookname(rs.getString("bookname"));
					vo.setAuthor(rs.getString("author"));
					vo.setPrice(rs.getInt("price"));
					vo.setBookimg(rs.getString("bookimg"));
					vo.setBookcount(rs.getInt("b_count"));
					dtos.add(vo);
				}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			if(pstmt!=null)try{pstmt.close();}catch(SQLException ex){}						
			if(conn!=null)try{conn.close();}catch(SQLException ex){}
		}
		return dtos;
	}
	@Override
	public int checkcart(int booknum) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		int checkcnt=0;
		try {
			conn=datasource.getConnection();
			String sql="select count(*) from book";
			pstmt=conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
				if(rs.next()) {
					checkcnt=rs.getInt(1);	//컬럼의 인덱스
				}
			}catch(SQLException e){
				e.printStackTrace();
			}finally {
				try {
					if(rs!=null) rs.close();
					if(pstmt!=null)pstmt.close();
					if(conn!=null)conn.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		return checkcnt;
	}
	@Override
	public int getSearchImgCnt(String bookimg) {
		int searchcnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
		conn=datasource.getConnection();
		String sql="select count(*) from book where bookimg=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, bookimg);
		rs=pstmt.executeQuery();
			if(rs.next()) {
				searchcnt=rs.getInt(1);	//컬럼의 인덱스
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return searchcnt;
	}
	@Override
	public ArrayList<HostVO> searchImg(int start, int end, String bookimg) {
		ArrayList<HostVO> dtos=null;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="select booknum,Bookname,Bookkind,Detail,author,Price,bookimg from book where bookimg=? order by booknum";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1,bookimg);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				dtos=new ArrayList<HostVO>(end-start+1);
				do {
					HostVO vo=new HostVO();
					vo.setBooknum(rs.getInt("booknum"));
					vo.setBookname(rs.getString("bookname"));
					vo.setBookkind(rs.getString("bookkind"));
					vo.setDetail(rs.getString("detail"));
					vo.setAuthor(rs.getString("author"));
					vo.setPrice(rs.getInt("price"));
					vo.setBookimg(rs.getString("bookimg"));
					dtos.add(vo);
				}while(rs.next());
			}
			}catch(SQLException e){
				e.printStackTrace();
			}finally {
				try {
					if(rs!=null) rs.close();
					if(pstmt!=null)pstmt.close();
					if(conn!=null)conn.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		return dtos;
	}
	@Override
	public ArrayList<HostVO> getBookkindList(String bookkind) {
		ArrayList<HostVO> dtos=null;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="SELECT * " + 
					"FROM (SELECT booknum,bookkind,detail,bookname,author,price,bookimg,b_count " + 
							"FROM("+ 
					            "select * from book " + 					            
					            ")" + 	
					        ")" + 
					"WHERE bookkind=?";	//넘겨받은 start값 end값을 rNum으로 조회
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, bookkind);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				dtos=new ArrayList<HostVO>(rs.getRow());
				do {
					HostVO vo=new HostVO();
					vo.setBooknum(rs.getInt("booknum"));
					vo.setBookkind(rs.getString("bookkind"));
					vo.setDetail(rs.getString("detail"));
					vo.setBookname(rs.getString("bookname"));
					vo.setAuthor(rs.getString("author"));
					vo.setPrice(rs.getInt("price"));
					vo.setBookimg(rs.getString("bookimg"));
					vo.setBookcount(rs.getInt("b_count"));
					dtos.add(vo);
					
				}while(rs.next());
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return dtos;
	}
	@Override
	public void deleteDeal(int deletenum) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=datasource.getConnection();
			String sql="delete deal where dealnum=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, deletenum);
			pstmt.executeUpdate();	
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
	@Override
	public void deleteComment(int commentnum) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=datasource.getConnection();
			String sql="delete boardcom where commentnum=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, commentnum);
			pstmt.executeUpdate();	
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
	@Override
	public void deletecart(HostVO vo) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=datasource.getConnection();
			String sql="delete cart where cartnum=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1,vo.getCartnum());
			int s=pstmt.executeUpdate();	
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			if(pstmt!=null)try{pstmt.close();}catch(SQLException ex){}						
			if(conn!=null)try{conn.close();}catch(SQLException ex){}
		}
	}
	@Override
	public HostVO cartnumfind(int cartnum) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		HostVO vo=new HostVO();
		try {
			conn=datasource.getConnection();
			String sql="select * from cart where cartnum=? ";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, cartnum);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				vo.setCartnum(rs.getInt("cartnum"));
				vo.setBooknum(rs.getInt("booknum"));
				vo.setBookkind(rs.getString("bookkind"));
				vo.setDetail(rs.getString("detail"));
				vo.setBookname(rs.getString("bookname"));
				vo.setAuthor(rs.getString("author"));
				vo.setPrice(rs.getInt("price"));
				vo.setBookimg(rs.getString("bookimg"));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			if(pstmt!=null)try{pstmt.close();}catch(SQLException ex){}						
			if(conn!=null)try{conn.close();}catch(SQLException ex){}
		}
		return vo;
	}
	@Override
	public ArrayList<Integer> monthSum(String start,String end) {
			ArrayList<Integer> sum=new ArrayList<Integer>(30);
			Connection conn=null;
			PreparedStatement pstmt=null;
			ResultSet rs=null;
			try {
				conn=datasource.getConnection();
				String sql="select SUM(price*b_count) as sum, " + 
						" to_char(orderdate,'YYYYMM') as orderdate " + 
						" from " + 
						" bookorder where to_char(orderdate, 'YYYYMM')"
						+ " between ? and ?" + 
						" group by " + 
						" to_char(orderdate,'YYYYMM')" +
						" order by orderdate";	
				pstmt=conn.prepareStatement(sql);
				pstmt.setString(1, start);
				pstmt.setString(2, end);
				rs=pstmt.executeQuery();
				while(rs.next()) {
					 sum.add(rs.getInt("sum"));
				}
			}catch(SQLException e){
				e.printStackTrace();
			}finally {
				try {
					if(rs!=null) rs.close();
					if(pstmt!=null)pstmt.close();
					if(conn!=null)conn.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		return sum;		
		}	

}
