package mvc_persistence;

import java.util.ArrayList;

import mvc_vo.HostVO;

public interface HostDAO {
	//로그인 시 아이디 비번 체크
	public int idPwdCheck(String id, String pwd);
	//도서추가
	public void bookadd(HostVO vo);
	//도서수정
	public void bookupdate(HostVO vo);
	//도서삭제
	public void bookdelete(HostVO vo);
	//회원삭제
	public void memberdelete(HostVO vo);
	//도서목록 불러오기
	public ArrayList<HostVO> getBookList(int start,int end);
	public ArrayList<HostVO> getBookList();
	//회원목록 불러오기
	public ArrayList<HostVO> getMemberList(int start,int end);
	//장바구니 담기
	public void inputcart(HostVO vo,String userid);
	//장바구니목록 불러오기
	public ArrayList<HostVO> getCartList(int start, int end,String id);	
	//주문목록 담기
	public void inputOrder(HostVO vo,String userid);
	//주문목록 불러오기(관리자용)
	public ArrayList<HostVO> getOrderList(int start, int end);
	//주문목록 불러오기(회원용)
	public ArrayList<HostVO> getOrderList( String id);
	//주문 시 삭제(주문목록에 추가하였을 떄 삭제)
	public void deletecart(HostVO vo, String userid);
	public void deletecart(HostVO vo);
	//주문상태 바꾸기
	public void changeorder(String orderstate,int cartnum);
	//주문상태 유무체크
	public int getStateCnt(String state);
	//주문목록 불러오기(state에 해당되는 조건)
	public ArrayList<HostVO> getStateList(int start, int end,String state);
	
	public ArrayList<HostVO> getRefundList(int start, int end,String state,String id); 
	//결산
	public int getTotal(int start, int end,String state);
	//도서목록 불러오기
	public ArrayList<HostVO> booksearch(int start,int end,String bookname,String bookselect);
	public ArrayList<HostVO> booksearch(int start,int end,int booknum);
	
	//도서종류 결산
	public int resultbk(String bookkind);
	//도서구분 결산
	public int resultdt(String bookkind);
	//도서가격 결산
	public int resultprice(int minprice,int maxprice);
	public int setbcount(HostVO vo,int bookcount,String name);
	public HostVO bookdb(int booknum);
	public HostVO cartdb(int booknum);
	public int setordercount(HostVO vo,int bookcount);
	public  ArrayList<HostVO>  imageinfo(String bookimg);
	public int checkcart(int booknum);
	//주문 db에서 해당 책 번호 불러오기
	public HostVO cartfind(int booknum);
	public HostVO cartnumfind(int cartnum);
	public HostVO orderfind(int cartnum);
	public int getSearchImgCnt(String bookimg);
	public ArrayList<HostVO> searchImg(int start, int end, String bookimg);
	public ArrayList<HostVO> getBookkindList(String bookkind);
	public int getMemberCnt(); 
	public int getCartCnt();
	public int getOrderCnt(String id);
	public int getBookCnt();
	public int getSearchCnt(String bookname,String bookselect);
	public void deleteDeal(int dealnum);
	public void deleteComment(int commentnum);
	public ArrayList<Integer> monthSum(String start,String end);
	public int getRefundCnt(String state,String id);
}
