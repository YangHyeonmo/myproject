package mvc_persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import mvc_vo.GuestVO;
import mvc_vo.HostVO;

public class GuestDAOImpl implements GuestDAO {

	private static GuestDAOImpl gd=new GuestDAOImpl();
	public static GuestDAOImpl getInstance() {
		return gd;
	}
	DataSource datasource;
	private GuestDAOImpl() {
		try {
			Context context=new InitialContext();
			datasource=(DataSource)context.lookup("java:comp/env/jdbc/Oracle11gHyeonmo");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	@Override
	public int insertGuest(GuestVO vo) {
		int insertCnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql=	"INSERT INTO member (membernum,id,password,phone,email,postnum,address,name,jumin) values(m_auto_inc.nextval,?,?,?,?,?,?,?,?)";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getPassword());
			pstmt.setString(3, vo.getHp());
			pstmt.setString(4, vo.getEmail());
			pstmt.setInt(5, vo.getPostnum());
			pstmt.setString(6, vo.getAddress());
			pstmt.setString(7,vo.getName());
			pstmt.setString(8,vo.getJumin());
			insertCnt=pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return insertCnt;
	}
	@Override
	public int idCheck(String id) {
		int checkCnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="select * from member where id=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1,id);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				checkCnt=1;
			}else {
				checkCnt=0;
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return checkCnt;
	}
	@Override
	public int idPwdCheck(String id, String pwd) {
		int logincnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="select * from  member where id=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				if(pwd.equals(rs.getString("password"))){
					logincnt=1;
				}else {
					logincnt=-1;
				}
			}else {
				logincnt=0;
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return logincnt;
	}
	@Override
	public GuestVO getMemberinfo(String id) {
		GuestVO mv=new GuestVO();
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="select * from  member where id=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				mv.setId(rs.getString("id"));
				mv.setPassword(rs.getString("password"));
				mv.setEmail(rs.getString("email"));
				mv.setHp(rs.getString("phone"));
				mv.setPostnum(rs.getInt("postnum"));
				mv.setAddress(rs.getString("address"));
				mv.setName(rs.getString("name"));
				mv.setJumin(rs.getString("jumin"));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return mv;
	}
	@Override
	public int updateMember(GuestVO vo) {
		int updatecnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=datasource.getConnection();
			String sql="update member set password=?,email=?,phone=?,postnum=?,address=?,name=? where id=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, vo.getPassword());
			pstmt.setString(2, vo.getEmail());
			pstmt.setString(3, vo.getHp());
			pstmt.setInt(4,vo.getPostnum());
			pstmt.setString(5, vo.getAddress());
			pstmt.setString(6, vo.getName());
			pstmt.setString(7, vo.getId());
			updatecnt=pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return updatecnt;
	}
	public int deleteMember(String id,String pwd) {
		int deletecnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=datasource.getConnection();
			String sql="delete member where id=? and password=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pwd);
			deletecnt=pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return deletecnt;
	}
	@Override
	public int infoMember(String id) {
		int infocnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=datasource.getConnection();
			String sql="select id,phone,email,postnum,address,name,jumin from member where id=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, id);
			infocnt=pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return infocnt;
	}

	@Override
	public ArrayList<GuestVO> getBoardList(int start, int end,String admin) {
		ArrayList<GuestVO> dtos=null;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="SELECT * " + 
					"FROM (SELECT boardnum,id,pwd,subject,content,readCnt,reg_date,membernum,rownum rNum " + 
							"FROM("+ 
					            "select * from board " + 					     
					            ")" + 	//최신글로부터 select한 레코드에 rowNum을 추가(삭제된 행 제외)
					        ")" + 
					"WHERE rNum >=? AND rNum<=? AND  NOT id=? order by boardnum desc";	//넘겨받은 start값 end값을 rNum으로 조회
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, start);
			pstmt.setInt(2, end);
			pstmt.setString(3, admin);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				dtos=new ArrayList<GuestVO>(end-start+1);
				do {
					GuestVO vo=new GuestVO();
					vo.setBoardnum(rs.getInt("boardnum"));
					vo.setId(rs.getString("id"));
					vo.setPwd(rs.getString("pwd"));
					vo.setSubject(rs.getString("subject"));
					vo.setContent(rs.getString("content"));
					vo.setReadCnt(rs.getInt("readCnt"));
					vo.setReg_date(rs.getTimestamp("reg_date"));
					dtos.add(vo);
				}while(rs.next());
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return dtos;
	}
	@Override
	public int addReadCnt(int boardnum) {
		int updatecnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="update board set readCnt=readCnt+1 where boardnum=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, boardnum);
			updatecnt=pstmt.executeUpdate();
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return updatecnt;
	}
	@Override
	public GuestVO getArticle(int num) {
		GuestVO vo=new GuestVO();
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="select * from board where boardnum=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				vo.setBoardnum(rs.getInt("boardnum"));
				vo.setReadCnt(rs.getInt("readCnt"));
				vo.setId(rs.getString("id"));
				vo.setReg_date(rs.getTimestamp("reg_date"));
				vo.setSubject(rs.getString("subject"));
				vo.setContent(rs.getString("content"));
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return vo;
	}
	
	@Override
	public int insertBoard(GuestVO vo) {
		int updatecnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		String sql=null;
		try {
			conn=datasource.getConnection();
			sql="insert INTO board(boardnum,id,pwd,subject,content,reg_date,membernum) VALUES(bd_seq.NEXTVAL,?,?,?,?,sysdate,(select membernum from member where id=?))";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getPwd());
			pstmt.setString(3, vo.getSubject());
			pstmt.setString(4, vo.getContent());
			pstmt.setString(5, vo.getId());
			updatecnt=pstmt.executeUpdate();
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return updatecnt;
	}
	@Override
	public int numPwdCheck(int num, String pwd) {
		int logincnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="select * from  board where boardnum=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				if(pwd.equals(rs.getString("pwd"))){
					logincnt=1;
				}else {
					logincnt=0;
				}
			}else {
				logincnt=0;
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return logincnt;
	}
	@Override
	public GuestVO getBoard(int boardnum) {
		GuestVO vo=new GuestVO();
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="select * from board where boardnum=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, boardnum);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				vo.setBoardnum(rs.getInt("boardnum"));
				vo.setId(rs.getString("id"));
				vo.setPwd(rs.getString("pwd"));
				vo.setSubject(rs.getString("subject"));
				vo.setContent(rs.getString("content"));
				vo.setReadCnt(rs.getInt("readCnt"));
				vo.setReg_date(rs.getTimestamp("reg_date"));	
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return vo;
	}
	@Override
	public int updateBoard(String subject, String content, int boardnum) {
		int updateCnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=datasource.getConnection();
			String sql="update board set subject=?,content=? where boardnum=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, subject);
			pstmt.setString(2, content);
			pstmt.setInt(3, boardnum);
			updateCnt=pstmt.executeUpdate();
			
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return updateCnt;
	}
	@Override
	public int deleteBoard(int boardnum) {
		int deleteCnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=datasource.getConnection();
			String sql="delete board where boardnum=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, boardnum);
			deleteCnt=pstmt.executeUpdate();
			
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return deleteCnt;
		
	}
	@Override
	public int insertDeal(GuestVO vo) {
		int insertCnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql=	"INSERT INTO deal (dealnum,membernum,dealimg,dealname,dealhow,dealplace,category,dealprice,readCnt,seller,dealstate) "
					+ "values(deal_seq.nextval,(select membernum from member where id=?),?,?,?,?,?,?,0,?,?)";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, vo.getSeller());
			pstmt.setString(2, vo.getDealimg());
			pstmt.setString(3, vo.getDealname());
			pstmt.setString(4, vo.getDealhow());
			pstmt.setString(5, vo.getDealplace());
			pstmt.setString(6,vo.getCategory());
			pstmt.setInt(7,vo.getDealprice());
			pstmt.setString(8, vo.getSeller());
			pstmt.setString(9, vo.getDealstate());
			insertCnt=pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return insertCnt;
	}
	@Override
	public int getDealCnt() {
		int dealcnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
		conn=datasource.getConnection();
		String sql="select count(*) from deal";
		pstmt=conn.prepareStatement(sql);
		rs=pstmt.executeQuery();
			if(rs.next()) {
				dealcnt=rs.getInt(1);	//컬럼의 인덱스
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return dealcnt;
	}
	@Override
	public ArrayList<GuestVO> getDealList(int start, int end) {
		ArrayList<GuestVO> dtos=null;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="SELECT * " + 
					"FROM (SELECT dealnum,membernum,dealimg,dealname,dealhow,dealplace,category,dealprice,seller,dealstate,rownum rNum " + 
							"FROM("+ 
					            "select * from deal " + 					            
					            ")" + 	
					        ")" + 
					"WHERE rNum >=? AND rNum<=? order by dealnum desc";	//넘겨받은 start값 end값을 rNum으로 조회
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, start);
			pstmt.setInt(2, end);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				dtos=new ArrayList<GuestVO>(end-start+1);
				do {
					GuestVO vo=new GuestVO();
					vo.setDealnum(rs.getInt("dealnum"));
					vo.setDealimg(rs.getString("dealimg"));
					vo.setDealname(rs.getString("dealname"));
					vo.setDealhow(rs.getString("dealhow"));
					vo.setDealplace(rs.getString("dealplace"));
					vo.setCategory(rs.getString("category"));
					vo.setDealprice(rs.getInt("dealprice"));
					vo.setSeller(rs.getString("seller"));
					vo.setDealstate(rs.getString("dealstate"));
					dtos.add(vo);
				}while(rs.next());
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return dtos;
	}
	@Override
	public int addDealCnt(int dealnum) {
		int updatecnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="update deal set readCnt=readCnt+1 where dealnum=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, dealnum);
			updatecnt=pstmt.executeUpdate();
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return updatecnt;
	}
	@Override
	public GuestVO getDeal(int dealnum) {
		GuestVO vo=new GuestVO();
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="select * from deal where dealnum=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, dealnum);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				vo.setDealnum(rs.getInt("dealnum"));
				vo.setReadCnt(rs.getInt("readCnt"));
				vo.setDealimg(rs.getString("dealimg"));
				vo.setDealname(rs.getString("dealname"));
				vo.setDealhow(rs.getString("dealhow"));
				vo.setDealplace(rs.getString("dealplace"));
				vo.setCategory(rs.getString("category"));
				vo.setDealprice(rs.getInt("dealprice"));
				vo.setSeller(rs.getString("seller"));
				vo.setDealstate(rs.getString("dealstate"));
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return vo;
	}
	@Override
	public int insertrequest(GuestVO vo) {
		int insertCnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql=	"INSERT INTO request (requestnum,membernum,dealnum,dealimg,dealname,requestprice,seller,buyer,message,requeststate) values(req_seq.nextval,(select membernum from member where id=?),?,?,?,?,?,?,?,?)";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, vo.getBuyer());
			pstmt.setInt(2, vo.getDealnum());
			pstmt.setString(3, vo.getDealimg());
			pstmt.setString(4, vo.getDealname());
			pstmt.setInt(5, vo.getRequestprice());
			pstmt.setString(6, vo.getSeller());
			pstmt.setString(7, vo.getBuyer());
			pstmt.setString(8,vo.getMessage());
			pstmt.setString(9,vo.getRequeststate());
			insertCnt=pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return insertCnt;
	}
	@Override
	public int getNoteCnt() {
		int notecnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
		conn=datasource.getConnection();
		String sql="select count(*) from request";
		pstmt=conn.prepareStatement(sql);
		rs=pstmt.executeQuery();
			if(rs.next()) {
				notecnt=rs.getInt(1);	//컬럼의 인덱스
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return notecnt;
	}
	@Override
	public ArrayList<GuestVO> getNoteList(int start, int end, String id) {
		ArrayList<GuestVO> dtos=null;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="SELECT * " + 
					"FROM (SELECT requestnum,membernum,dealnum,dealimg,dealname,requestprice,seller,buyer,message,requeststate,rownum rNum " + 
							"FROM("+ 
					            "select * from request " + 					            
					            ")" + 	
					        ")" + 
					"WHERE rNum >=? AND rNum<=? AND  seller=? order by dealnum";	//넘겨받은 start값 end값을 rNum으로 조회
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, start);
			pstmt.setInt(2, end);
			pstmt.setString(3, id);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				dtos=new ArrayList<GuestVO>(end-start+1);
				do {
					GuestVO vo=new GuestVO();
					vo.setRequestnum(rs.getInt("requestnum"));
					vo.setDealnum(rs.getInt("dealnum"));
					vo.setDealimg(rs.getString("dealimg"));
					vo.setDealname(rs.getString("dealname"));
					vo.setRequestprice(rs.getInt("requestprice"));
					vo.setSeller(rs.getString("seller"));
					vo.setBuyer(rs.getString("buyer"));
					vo.setMessage(rs.getString("message"));
					vo.setRequeststate(rs.getString("requeststate"));
					dtos.add(vo);
				}while(rs.next());
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return dtos;
	}
	@Override
	public void deleterequest(GuestVO vo) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=datasource.getConnection();
			String sql="delete request where requestnum=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, vo.getRequestnum());
			int s=pstmt.executeUpdate();	
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			if(pstmt!=null)try{pstmt.close();}catch(SQLException ex){}						
			if(conn!=null)try{conn.close();}catch(SQLException ex){}
		}
	}
	@Override
	public void changedeal(GuestVO vo) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=datasource.getConnection();
			String sql="update deal set dealstate=? where dealnum=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, vo.getDealstate());
			pstmt.setInt(2, vo.getDealnum());
			int s=pstmt.executeUpdate();	
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			if(pstmt!=null)try{pstmt.close();}catch(SQLException ex){}						
			if(conn!=null)try{conn.close();}catch(SQLException ex){}
		}
	}
	@Override
	public GuestVO getNote(int requestnum) {
		GuestVO vo=new GuestVO();
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="select * from request where requestnum=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, requestnum);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				vo.setRequestnum(rs.getInt("requestnum"));
				vo.setDealnum(rs.getInt("dealnum"));
				vo.setDealimg(rs.getString("dealimg"));
				vo.setDealname(rs.getString("dealname"));
				vo.setRequestprice(rs.getInt("requestprice"));
				vo.setSeller(rs.getString("seller"));
				vo.setBuyer(rs.getString("buyer"));
				vo.setMessage(rs.getString("message"));
				vo.setRequeststate(rs.getString("requeststate"));
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return vo;
	}
	@Override
	public int insertcomment(GuestVO vo) {
		int updatecnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		String sql=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			sql="insert INTO boardcom(commentnum,boardnum,membernum,commentid,content) VALUES(com_seq.NEXTVAL,?,(select membernum from member where id=?),?,?)";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, vo.getBoardnum());
			pstmt.setString(2, vo.getCommentid());
			pstmt.setString(3, vo.getCommentid());
			pstmt.setString(4, vo.getContent());
			int s=pstmt.executeUpdate();	
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return updatecnt;
	}
	@Override
	public int getCommentCnt(int boardnum) {
		int commentcnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
		conn=datasource.getConnection();
		String sql="select count(*) from boardcom where boardnum=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setInt(1, boardnum);
		rs=pstmt.executeQuery();
			if(rs.next()) {
				commentcnt=rs.getInt(1);	//컬럼의 인덱스
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return commentcnt;
	}
	@Override
	public ArrayList<GuestVO> getCommentList(int start, int end, int boardnum) {
		ArrayList<GuestVO> dtos=null;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="SELECT * " + 
					"FROM (SELECT commentnum,boardnum,membernum,commentid,content " + 
					"FROM(" + 
			            "select * from boardcom " + 
			            ")" + 	
			        ")" + 
			"WHERE boardnum=? order by commentnum";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, boardnum);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				dtos=new ArrayList<GuestVO>(end-start+1);
				do{
					GuestVO vo=new GuestVO();
					vo.setCommentnum(rs.getInt("commentnum"));
					vo.setBoardnum(rs.getInt("boardnum"));
					vo.setCommentid(rs.getString("commentid"));
					vo.setContent(rs.getString("content"));
					dtos.add(vo);
				}while(rs.next());
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return dtos;
	}
	
	
	@Override
	public String matchid(String findemail, String findphone) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		GuestVO vo=null;
		try {
			conn=datasource.getConnection();
			String sql="select id from member where email=? AND phone=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, findemail);
			pstmt.setString(2, findphone);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				vo=new GuestVO();
				vo.setId(rs.getString("id"));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return vo.getId();
	}
	@Override
	public String matchpwd(String findid, String findemail, String findphone) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		GuestVO vo=null;
		try {
			conn=datasource.getConnection();
			String sql="select password from member where id=? AND email=? AND phone=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, findid);
			pstmt.setString(2, findemail);
			pstmt.setString(3, findphone);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				vo=new GuestVO();
				vo.setPassword(rs.getString("password"));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return vo.getPassword();
	}
	@Override
	public ArrayList<GuestVO> boardsearch(int start,int end,String board,String boardselect) {
		ArrayList<GuestVO> dtos=null;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="SELECT * " + 
			"FROM (SELECT boardnum,id,pwd,subject,content,readCnt,reg_date,membernum,rownum rNum " + 
					"FROM("+ 
			            "select * from board " + 					           
			            ")" + 	//최신글로부터 select한 레코드에 rowNum을 추가(삭제된 행 제외)
			        ")" + 
			"where "+boardselect+" Like ? AND rNum>=? AND rNum<=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1,board+"%");
			pstmt.setInt(2, start);
			pstmt.setInt(3, end);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				dtos=new ArrayList<GuestVO>(end-start+1);
				do {
					GuestVO vo=new GuestVO();
					vo.setBoardnum(rs.getInt("boardnum"));
					vo.setId(rs.getString("id"));
					vo.setSubject(rs.getString("subject"));
					vo.setReg_date(rs.getTimestamp("reg_date"));
					vo.setReadCnt(rs.getInt("readcnt"));		
					dtos.add(vo);
				}while(rs.next());
			}
			}catch(SQLException e){
				e.printStackTrace();
			}finally {
				try {
					if(rs!=null) rs.close();
					if(pstmt!=null)pstmt.close();
					if(conn!=null)conn.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		return dtos;
	}
	@Override
	public int getBoardCnt() {
		int boardcnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
		conn=datasource.getConnection();
		String sql="select count(*) from board ";
		pstmt=conn.prepareStatement(sql);
		rs=pstmt.executeQuery();
			if(rs.next()) {
				boardcnt=rs.getInt(1);	//컬럼의 인덱스
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return boardcnt;
	}
	@Override
	public ArrayList<GuestVO> dealsearch(int start, int end, String deal, String dealselect) {
		ArrayList<GuestVO> dtos=null;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="select * from deal where "+dealselect+"  Like ? order by dealnum";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1,deal+"%");
			rs=pstmt.executeQuery();
			if(rs.next()) {
				dtos=new ArrayList<GuestVO>(end-start+1);
				do {
					GuestVO vo=new GuestVO();
					vo.setDealnum(rs.getInt("dealnum"));
					vo.setReadCnt(rs.getInt("readCnt"));
					vo.setDealimg(rs.getString("dealimg"));
					vo.setDealname(rs.getString("dealname"));
					vo.setDealhow(rs.getString("dealhow"));
					vo.setDealplace(rs.getString("dealplace"));
					vo.setCategory(rs.getString("category"));
					vo.setDealprice(rs.getInt("dealprice"));
					vo.setSeller(rs.getString("seller"));
					vo.setDealstate(rs.getString("dealstate"));
					dtos.add(vo);
				}while(rs.next());
			}
			}catch(SQLException e){
				e.printStackTrace();
			}finally {
				try {
					if(rs!=null) rs.close();
					if(pstmt!=null)pstmt.close();
					if(conn!=null)conn.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		return dtos;
	}
	@Override
	public ArrayList<GuestVO> getAdminList(int start, int end, String admin) {
		ArrayList<GuestVO> dtos=null;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=datasource.getConnection();
			String sql="SELECT * " + 
					"FROM (SELECT boardnum,id,pwd,subject,content,readCnt,reg_date,membernum,rownum rNum " + 
							"FROM("+ 
					            "select * from board " + 					           
					            ")" + 	//최신글로부터 select한 레코드에 rowNum을 추가(삭제된 행 제외)
					        ")" + 
					"WHERE rNum >=? AND rNum<=? AND id=?";	//넘겨받은 start값 end값을 rNum으로 조회
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, start);
			pstmt.setInt(2, end);
			pstmt.setString(3, admin);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				dtos=new ArrayList<GuestVO>(end-start+1);
				do {
					GuestVO vo=new GuestVO();
					vo.setBoardnum(rs.getInt("boardnum"));
					vo.setId(rs.getString("id"));
					vo.setPwd(rs.getString("pwd"));
					vo.setSubject(rs.getString("subject"));
					vo.setContent(rs.getString("content"));
					vo.setReadCnt(rs.getInt("readCnt"));
					vo.setReg_date(rs.getTimestamp("reg_date"));
					dtos.add(vo);
				}while(rs.next());
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return dtos;
	}
	@Override
	public GuestVO getAddress(String userid) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		GuestVO vo=null;
		try {
			conn=datasource.getConnection();
			String sql="select id,phone,postnum,address from member where id=?";
			pstmt=conn.prepareStatement(sql);
		    pstmt.setString(1, userid);
		    rs=pstmt.executeQuery();
		    if(rs.next()) {
			do {
				vo=new GuestVO();
				vo.setAddress(rs.getString("address"));
				vo.setPostnum(rs.getInt("postnum"));
				vo.setId(rs.getString("id"));
				vo.setHp(rs.getString("phone"));
			}while(rs.next());
		    }
		}catch(Exception e) {
			e.printStackTrace();
		}
		return vo;
	}
	@Override
	public int getPageCnt(String board,String boardselect,String admin) {
		int boardcnt=0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
		conn=datasource.getConnection();
		String sql="SELECT COUNT(*) FROM  board WHERE "+boardselect+" Like ? AND NOT id=?"; 
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, board+"%");
		pstmt.setString(2, admin);
		rs=pstmt.executeQuery();
			if(rs.next()) {
				boardcnt=rs.getInt(1);	//컬럼의 인덱스
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return boardcnt;
	}
}
