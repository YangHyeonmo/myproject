var msg_id = "아이디를 입력하세요";
var msg_pwd = "비밀번호를 입력하세요";
var msg_repwd = "비밀번호를 확인하세요";
var msg_pwdChk = "비밀번호가 일치하지 않습니다";
var msg_name = "이름을 입력하세요";
var msg_phone1 = "휴대폰 번호를 입력하세요";
var msg_phone2 = "휴대폰 번호를 모두 입력하세요";
var msg_jumin1 = "주민번호를 입력하세요";
var msg_jumin2 = "주민번호 뒷자리를 입력하세요";
var msg_email = "이메일을 입력하세요";
var msg_emailChk = "이메일 형식에 일치하지 않습니다";
var msg_confirmId = "중복확인을 해주세요";
var msg_subject = "제목을 입력해주세요";
var insertError = "회원가입에 실패하셨습니다";
var updateError = "회원 정보수정에 실패하셨습니다";
var deleteError = "회원탈퇴에 실패하셨습니다";
var passwdError = "비밀번호가 일치하지 않습니다";
var bookError = "도서를 입력하세요";
var booknumError = "도서번호를 입력하세요;"
var countError = "수량을 입력하세요";
var minmaxError = "수량을 정확하게 입력하세요";
var loginError = "로그인이 필요합니다";
var searchError = "정확하게 입력해주세요";
$(function() {
	$("#all").click(function() {
		if ($("#all").prop("checked")) {
			$(".check").prop("checked", true);
		} else {
			$(".check").prop("checked", false);
		}
	})
})
function orderChange() {
	if ($("#order").is(":checked")) {
		$("#receiver").val(document.bookform.cartid.value);
		$("#re_phone").val(document.bookform.cartphone.value);
		$("#re_post").val(document.bookform.cartaddress.value);
	} else {
		$("#receiver").val("");
		$("#re_phone").val("");
		$("#re_post").val("");
	}
}
function bkChange() {
	var bookkind = [ "국내도서", "해외도서", "신간도서", "베스트셀러" ];
	var bookin = [ "소설", "시/에세이", "경제/경영", "자기계발" ];
	var bookout = [ "영미도서", "문학", "인문/사회", "자기계발" ];
	var booknew = [ "화제의 신간" ];
	var bookbest = [ "베스트셀러" ];
	var selectItem = $("#bookkind").val();
	var changeItem;
	if (selectItem == "국내도서") {

		changeItem = bookin;
	} else if (selectItem == "해외도서") {
		changeItem = bookout;
	} else if (selectItem == "신간도서") {
		changeItem = booknew;
	} else if (selectItem == "베스트셀러") {
		changeItem = bookbest;
	}
	$('#detail').empty();
	for (var count = 0; count < changeItem.length; count++) {
		$('<option>' + changeItem[count] + '</option>').appendTo('#detail');
	}
}
function dpChange() {
	var seoul = [ "강남", "사당", "잠실", "교대", "선릉" ];
	var gki = [ "수원", "안양", "남양주", "과천", "파주" ];
	var incheon = [ "부평", "원인재", "센트럴파크", "인천대입구" ];
	var selectItem = $("#dealplace1").val();
	var changeItem;
	if (selectItem == "서울") {
		changeItem = seoul;
	} else if (selectItem == "경기") {
		changeItem = gki;
	} else if (selectItem == "인천") {
		changeItem = incheon;
	}
	$('#dealplace2').empty();
	for (var count = 0; count < changeItem.length; count++) {
		$('<option>' + changeItem[count] + '</option>').appendTo('#dealplace2');
	}
}
function cartCheck() {
	if (!document.bookform.receiver.value) {
		alert("받으실 분을 입력하세요");
		document.bookform.receiver.focus();
		return false;
	} else if (!document.bookform.re_phone.value) {
		alert("받으실 분의 핸드폰 번호를 입력하세요");
		document.bookform.re_phone.focus();
		return false;
	} else if (!document.bookform.re_post.value) {
		alert("받으실 분의 주소을 입력하세요");
		document.bookform.re_post.focus();
		return false;
	}
}
function errorAlert(errorMsg) {
	alert(errorMsg);
	// 이전 페이지로 이동
	window.history.back();
}
function resultCheck() {
	var min = document.getElementById("minprice");
	var max = document.getElementById("mxaprice");
	if (min <= max) {
		alert(minmaxError);
		document.resultform.minprice.value = "";
		document.resultform.maxprice.value = "";
		document.resultform.minprice.focus();
		return false;
	}
}

function mainCheck() {
	if (!document.signin.id.value) {
		alert(msg_id);
		document.signin.id.focus();
		return false;
	} else if (!document.signin.pwd.value) {
		alert(msg_pwd);
		document.signin.pwd.focus();
		return false;
	}
}
function mainFocus() {
	document.signin.id.focus();
}
function inputFocus() {
	document.inputform.id.focus();
}
function bookCheck() {
	if (!document.bookform.cartnum.value) {
		alert(bookError);
		document.bookform.cartnum.focus();
		return false;
	} else if (!document.bookform.count.value) {
		alert(countError);
		document.bookform.count.focus();
		return false;
	}
}
function buy(){
	document.cartform.action = "cartadd.guest";
}
function nowbuy(){
	document.cartform.action = "orderadd.guest";
}
function orderadd() {
	cartCheck();
	document.bookform.action = "orderadd.guest";
}
function cartdelete() {
	document.bookform.action = "cartdelete.guest";
}
// 회원가입 체크
function inputCheck() {
	if (!document.signin.txtUserName.value) {
		alert(msg_id);
		var id = document.getElementById("txtUserName");
		id.style.backgroundColor = "lightblue";
		document.signin.txtUserName.focus();
		return false;
	} else if (!document.signin.txtPassword.value) {
		alert(msg_pwd);
		var pwd = document.getElementById("txtPassword");
		pwd.style.backgroundColor = "lightblue";
		document.signin.txtPassword.focus();
		return false;
	} else if (!document.signin.txtPassword2.value) {
		alert(msg_repwd);
		var pwd2 = document.getElementById("txtPassword2");
		pwd2.style.backgroundColor = "lightblue";
		document.signin.txtPassword2.focus();
		return false;
	} else if (document.signin.txtPassword.value !== document.signin.txtPassword2.value) {
		alert(msg_pwdChk);
		document.signin.txtPassword2.value = "";
		document.signin.txtPassword2.focus();
		return false;
	} else if (!document.signin.username.value) {
		alert(msg_name);
		var name = document.getElementById("username");
		name.style.backgroundColor = "lightblue";
		document.signin.username.focus();
		return false;
	} else if (!document.signin.jumin1.value) {
		alert(msg_jumin1);
		var jumin1 = document.getElementById("jumin1");
		jumin1.style.backgroundColor = "lightblue";
		document.signin.jumin1.focus();
		return false;
	} else if (!document.signin.jumin2.value) {
		alert(msg_jumin2);
		var jumin2 = document.getElementById("jumin2");
		jumin2.style.backgroundColor = "lightblue";
		document.signin.jumin2.focus();
		return false;
	} else if (!document.signin.hp2.value) {
		alert(msg_phone1);
		var hp2 = document.getElementById("hp2");
		hp2.style.backgroundColor = "lightblue";
		document.signin.hp2.focus();
		return false;
	} else if (!document.signin.hp3.value) {
		alert(msg_phone2);
		var hp3 = document.getElementById("hp3");
		hp3.style.backgroundColor = "lightblue";
		document.signin.hp3.focus();
		return false;
	} else if (!document.signin.txtEmail.value) {
		alert(msg_email);
		var email = document.getElementById("txtEmail");
		email.style.backgroundColor = "lightblue";
		document.signin.txtEmail.focus();
		return false;
	} else if (!document.signin.post.value) {
		alert("주소번호를 정확하게 입력하세요");
		var email = document.getElementById("post");
		email.style.backgroundColor = "lightblue";
		document.signin.post.focus();
		return false;
	} else if (!document.signin.addr1.value) {
		alert("주소를 다시 입력하세요");
		var add1 = document.getElementById("addr1");
		add1.style.backgroundColor = "lightblue";
		document.signin.addr1.focus();
		return false;
	} else if (!document.signin.addr2.value) {
		alert("주소를 정확하게 입력하세요");
		var add2 = document.getElementById("addr2");
		add2.style.backgroundColor = "lightblue";
		document.signin.addr2.focus();
		return false;
	} else if (document.signin.hiddenid.value == 0) {
		alert(msg_confirmId);
		var dup = document.getElementById("dup");
		dup.style.backgroundColor = "lightblue";
		document.signin.dupChk.focus();
		return false;
	} else if (!document.signin.findid.value) {
		alert(msg_id);
		var findid = document.getElementById("findid");
		findid.style.backgroundColor = "lightblue";
		document.signin.findid.focus();
		return false;
	} else if (!document.signin.findpwd.value) {
		alert(msg_pwd);
		var findpwd = document.getElementById("findpwd");
		findpwd.style.backgroundColor = "lightblue";
		document.signin.findpwd.focus();
		return false;
	}
}


// 회원탈퇴 비밀번호 체크

function deleteCheck() {
	if (!document.deleteform.pwd.value) {
		alert(msg_pwd);
		document.deleteform.pwd.focus();
		return false;
	}
}
// 주문목록에 추가할 도서번호 체크
function cartaddCheck() {
	if (!document.cartform.booknum.value) {
		alert(booknumError);
		document.cartform.booknum.focus();
		return false;
	}
}
// 중복확인창에서 id입력여부
function confirmIdCheck() {
	if (!document.confirmform.id.value) {
		document.confirmform.id.focus();
		return false;
	}
}
function selectEmailChk() {
	if (document.inputform.email3.value == 0) {
		document.inputform.email2.value = "";
		document.inputform.email2.focus();
	} else {
		document.inputform.email2.value = document.inputform.email3.value;
	}
}
// 중복확인창
function confirmId() {
	if (!document.signin.txtUserName.value) {
		alert(msg_id);
		document.signin.txtUserName.focus();
		return false;
	}
	/*
	 * window.open("파일명","윈도우명","창속성"); url="주소?속성"+ 속성값;-->get방식
	 */
	var url = "confirmId.guest?id=" + document.signin.txtUserName.value;
	window.open(url, "confirm", "menubar=no,width=200,height=200");
}
function nextHp1() {
	if (document.inputform.hp1.value.length >= 3) {
		document.inputform.hp2.focus();
	}
}
function nextHp2() {
	if (document.inputform.hp2.value.length >= 4) {
		document.inputform.hp3.focus();
	}
}
function nextHp3() {
	if (document.inputform.hp3.value.length >= 4) {
		document.inputform.email1.focus();
	}
}
function setId(id) {
	opener.document.signin.txtUserName.value = id;
	opener.document.signin.hiddenid.value = "1";
	self.close();
}
